# Composite ordered seek: local read qualification

The measured source is `bcfcdedf0474575823ab4aa1242a1c94190f2311`; runtime implementation is unchanged from `552d4b4e0b3201cb35a19cc86522596add4ed249`. The following documentation/artifact commit does not change measured runtime or benchmark code. This is local macOS arm64 evidence with pinned Rust 1.97.1 and the repository release profile (opt-level 3, thin LTO, one codegen unit), without target overrides. It does not establish remote CI, concurrent-writer acceptance or hardware-independent performance.

## Protocol and correctness

Eight fresh processes cover 64, 1,000, 10,000 and 100,000 rows in resident and reopened OutOfCore modes. Every fixture has 80% `kind = note`, four rows per integer rank, unique string IDs and a 256-byte body. The composite index is `(kind, rank, id)`. Each direction uses the first page, a midpoint continuation and a near-end continuation; pages contain at most 32 rows. For DESC, a large continuation is near the beginning of the eligible descending stream, not an exhausted tail. Depth zero denotes no continuation.

The reference runs the identical filter and scalar projection, replacing only `ORDER BY rank` with `ORDER BY coalesce(rank, 0)` to disable index-order inference. Non-null INT rank makes those sort keys equivalent. The benchmark asserts the native ordered plan, a reference TopN/Sort plan and exact typed row/order equality on every pair. The same read transaction pins each comparison sequence. API regressions separately prove complete page concatenation, ties, updates/deletions, retained snapshots and reopen; this read-only benchmark alone does not qualify concurrent writes.

Each case retains one labelled warmup and seven measured pairs, alternating path order. The 48 cases contain 384 pairs including warmups, 336 measured pairs. Tables divide median ordered latency by median reference latency; ratios above one are slower. All samples, including unfavorable pairs, are retained in `raw/`; no favorable retry or sample removal is applied. No compiler or HawDB campaign was active at measurement start. Other host activity, CPU affinity and thermal state are uncontrolled.

Persistent fixtures are built in explicit Materialized mode using 4,096-row transactions, then fully validated by CREATE UNIQUE, indexed, checkpointed and reopened in OutOfCore mode. An exact count preflight runs before timing and can warm canonical storage. Default WAL limits and SyncOnEveryWrite remain in effect. These are warm read comparisons, not device-cold measurements or write/DDL throughput qualification.

## Latency

Values are median microseconds per page.

| Rows | Backend | Direction | Continuation | Output rows | Ordered us | Reference us | Ratio |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: |
| 64 | memory | ASC | 0 | 32 | 77.8 | 121.6 | 0.6402 |
| 64 | memory | ASC | 32 | 25 | 88.2 | 108.1 | 0.8165 |
| 64 | memory | ASC | 62 | 1 | 59.2 | 65.1 | 0.9098 |
| 64 | memory | DESC | 0 | 32 | 63.5 | 101.1 | 0.6279 |
| 64 | memory | DESC | 32 | 25 | 74.1 | 90.4 | 0.8202 |
| 64 | memory | DESC | 62 | 32 | 86.6 | 123.6 | 0.7007 |
| 64 | disk | ASC | 0 | 32 | 119.1 | 147.0 | 0.8099 |
| 64 | disk | ASC | 32 | 25 | 130.2 | 145.5 | 0.8949 |
| 64 | disk | ASC | 62 | 1 | 67.9 | 97.5 | 0.6966 |
| 64 | disk | DESC | 0 | 32 | 112.6 | 129.2 | 0.8710 |
| 64 | disk | DESC | 32 | 25 | 112.8 | 128.7 | 0.8763 |
| 64 | disk | DESC | 62 | 32 | 122.5 | 144.2 | 0.8492 |
| 1000 | memory | ASC | 0 | 32 | 60.4 | 706.9 | 0.0855 |
| 1000 | memory | ASC | 500 | 32 | 70.0 | 421.8 | 0.1659 |
| 1000 | memory | ASC | 998 | 1 | 41.8 | 84.5 | 0.4946 |
| 1000 | memory | DESC | 0 | 32 | 51.5 | 745.9 | 0.0690 |
| 1000 | memory | DESC | 500 | 32 | 63.8 | 418.6 | 0.1523 |
| 1000 | memory | DESC | 998 | 32 | 66.6 | 763.0 | 0.0873 |
| 1000 | disk | ASC | 0 | 32 | 135.2 | 1142.6 | 0.1183 |
| 1000 | disk | ASC | 500 | 32 | 238.8 | 818.2 | 0.2919 |
| 1000 | disk | ASC | 998 | 1 | 80.1 | 467.8 | 0.1712 |
| 1000 | disk | DESC | 0 | 32 | 278.6 | 996.0 | 0.2797 |
| 1000 | disk | DESC | 500 | 32 | 184.7 | 681.4 | 0.2711 |
| 1000 | disk | DESC | 998 | 32 | 263.1 | 937.4 | 0.2807 |
| 10000 | memory | ASC | 0 | 32 | 73.6 | 5844.3 | 0.0126 |
| 10000 | memory | ASC | 5000 | 32 | 83.6 | 3357.6 | 0.0249 |
| 10000 | memory | ASC | 9998 | 1 | 38.8 | 374.2 | 0.1038 |
| 10000 | memory | DESC | 0 | 32 | 71.0 | 6586.6 | 0.0108 |
| 10000 | memory | DESC | 5000 | 32 | 83.9 | 3736.9 | 0.0224 |
| 10000 | memory | DESC | 9998 | 32 | 93.0 | 7087.7 | 0.0131 |
| 10000 | disk | ASC | 0 | 32 | 308.2 | 7674.5 | 0.0402 |
| 10000 | disk | ASC | 5000 | 32 | 1111.9 | 5304.8 | 0.2096 |
| 10000 | disk | ASC | 9998 | 1 | 286.2 | 3106.8 | 0.0921 |
| 10000 | disk | DESC | 0 | 32 | 2068.5 | 7919.7 | 0.2612 |
| 10000 | disk | DESC | 5000 | 32 | 1168.7 | 5824.6 | 0.2006 |
| 10000 | disk | DESC | 9998 | 32 | 2149.1 | 8229.5 | 0.2611 |
| 100000 | memory | ASC | 0 | 32 | 120.9 | 61481.8 | 0.0020 |
| 100000 | memory | ASC | 50000 | 32 | 150.5 | 37623.0 | 0.0040 |
| 100000 | memory | ASC | 99998 | 1 | 73.4 | 5032.6 | 0.0146 |
| 100000 | memory | DESC | 0 | 32 | 121.5 | 70107.2 | 0.0017 |
| 100000 | memory | DESC | 50000 | 32 | 118.8 | 38996.0 | 0.0030 |
| 100000 | memory | DESC | 99998 | 32 | 155.7 | 80977.5 | 0.0019 |
| 100000 | disk | ASC | 0 | 32 | 482.3 | 72455.2 | 0.0067 |
| 100000 | disk | ASC | 50000 | 32 | 549.4 | 53059.8 | 0.0104 |
| 100000 | disk | ASC | 99998 | 1 | 153.4 | 31138.3 | 0.0049 |
| 100000 | disk | DESC | 0 | 32 | 245.0 | 81038.2 | 0.0030 |
| 100000 | disk | DESC | 50000 | 32 | 546.7 | 57338.5 | 0.0095 |
| 100000 | disk | DESC | 99998 | 32 | 280.9 | 84569.1 | 0.0033 |

## Index work and resource tradeoffs

Encoded block hashing still visits the bounded source bytes on warm access; warm binary key seeking does not imply logarithmic total byte/CPU work. The first cold ordered access fully validates one bounded block before caching a verified view. Admission precedes construction, and cache refusal keeps an admitted uncached path. The immutable bytes and offsets consume the existing shared SegmentCache, not an unbounded private cache.

Index byte counters describe logical property block bytes and omit canonical hydration and other scan I/O. A reference index-byte count of zero does not mean zero I/O. Query peak accounting is conservative admitted ownership rather than actual heap/RSS. Cache residency is shared with both paths, whose alternating order affects the observed before/after values. Raw reports retain capacity, residency, pinned bytes, evictions and admission refusals. No cold-device, total-IO or process-memory reduction is claimed.

| Disk rows | Direction | Continuation | Warm decoded entries | Blocks | Descriptor page visits | Logical index bytes | Ordered query peak bytes | Reference query peak bytes |
| ---: | --- | ---: | --- | --- | --- | --- | ---: | ---: |
| 64 | ASC | 0 | 40 | 1 | 4 | 3518 | 16783456 | 16994002 |
| 64 | ASC | 32 | 33 | 1 | 4 | 3518 | 16782091 | 16884186 |
| 64 | ASC | 62 | 9 | 1 | 4 | 3518 | 16777411 | 16782842 |
| 64 | DESC | 0 | 40 | 1 | 4 | 3518 | 16783456 | 16994002 |
| 64 | DESC | 32 | 34 | 1 | 4 | 3518 | 16782091 | 16884186 |
| 64 | DESC | 62 | 40 | 1 | 4 | 3518 | 16783456 | 16985594 |
| 1000 | ASC | 0 | 44 | 1 | 4 | 53687 | 16783456 | 17906382 |
| 1000 | ASC | 500 | 44 | 1 | 4 | 53687 | 16783456 | 17858894 |
| 1000 | ASC | 998 | 13 | 1 | 4 | 53687 | 16777411 | 16782842 |
| 1000 | DESC | 0 | 43 | 1 | 4 | 53687 | 16783456 | 17906382 |
| 1000 | DESC | 500 | 44 | 1 | 4 | 53687 | 16783456 | 17858894 |
| 1000 | DESC | 998 | 44 | 1 | 4 | 53687 | 16783456 | 17906382 |
| 10000 | ASC | 0 | 48 | 1 | 4 | 536087 | 16783456 | 17906382 |
| 10000 | ASC | 5000 | 47 | 1 | 4 | 536087 | 16783456 | 17906382 |
| 10000 | ASC | 9998 | 16 | 1 | 4 | 536087 | 16777411 | 16782842 |
| 10000 | DESC | 0 | 47 | 1 | 4 | 536087 | 16783456 | 17906382 |
| 10000 | DESC | 5000 | 47 | 1 | 4 | 536087 | 16783456 | 17906382 |
| 10000 | DESC | 9998 | 47 | 1 | 4 | 536087 | 16783456 | 17906382 |
| 100000 | ASC | 0 | 49 | 1 | 6 | 1048548 | 16783456 | 17906382 |
| 100000 | ASC | 50000 | 48 | 1 | 6 | 1048533 | 16783456 | 17906382 |
| 100000 | ASC | 99998 | 14 | 1 | 6 | 117800 | 16777411 | 16782842 |
| 100000 | DESC | 0 | 45 | 1 | 5 | 117800 | 16783456 | 17906382 |
| 100000 | DESC | 50000 | 48 | 1 | 6 | 1048533 | 16783456 | 17906382 |
| 100000 | DESC | 99998 | 45 | 1 | 5 | 117800 | 16783456 | 17906382 |

Ordered blocking-operator peak is zero in this fixture; the reference TopN retains admitted blocking state. Total query peak can remain substantial because read scratch/canonical hydration are separate from sort state. Resource refusal, cancellation, consumer failure and cache refusal belong to focused correctness tests, not these successful latency samples.

## Ordinary point-query control

Baseline `bb7d213cd114b69d248397dd93a093b0ad035841` contains both composite-range correctness fixes and has the same runtime as PR base `c6bd40630a94516b8a2c55abf466424c0a0e0788`; their differences are schema-index tests and TEST_INDEX documentation. The candidate uses the measured source. Both hosts use identical main.rs and Cargo.lock, the repository working directory/profile and pinned compiler. Their only dependency difference is the library checkout path. Saved binary hashes identify each executable.

Five fresh process pairs per schema variant alternate baseline/candidate order, and schema order also alternates. Each process warms 1,000 lookups and retains eleven batches of 1,000 lookups rotating 64 IDs in a 1,000-row fixture. Every retained batch has exactly 1,000 cache hits, zero misses and checksum 7,380; every query returns one correctly typed row. The optional composite schema is irrelevant to the point query and detects accidental proof/catalog work on that path. Ratios compare candidate and baseline medians within a fresh pair. This finite, single-host warm-cache control is not a universal no-regression bound.

| Composite schema | Pair | Baseline us/lookup | Candidate us/lookup | Ratio |
| --- | ---: | ---: | ---: | ---: |
| False | 0 | 15.862 | 16.493 | 1.0398 |
| False | 1 | 15.660 | 16.033 | 1.0238 |
| False | 2 | 15.843 | 16.366 | 1.0330 |
| False | 3 | 15.849 | 15.978 | 1.0082 |
| False | 4 | 15.909 | 15.985 | 1.0048 |
| True | 0 | 15.973 | 16.359 | 1.0242 |
| True | 1 | 15.806 | 16.111 | 1.0193 |
| True | 2 | 16.086 | 15.898 | 0.9883 |
| True | 3 | 15.940 | 16.340 | 1.0251 |
| True | 4 | 15.980 | 16.796 | 1.0511 |

Median paired ratio with composite schema `False`: **1.0238**.

Median paired ratio with composite schema `True`: **1.0242**.

## Preparation cost and retained adverse evidence

Complete setup includes schema, bounded fixture writes, full uniqueness validation, index construction, checkpoint/reopen when applicable and exact count preflight. It is outside read timing.

| Rows | Resident setup s | Disk setup s |
| ---: | ---: | ---: |
| 64 | 0.005 | 1.114 |
| 1000 | 0.014 | 1.171 |
| 10000 | 0.122 | 1.307 |
| 100000 | 1.276 | 3.215 |

- Initial source `38b5c6c4` decoded all 10,000 keys per page in a single default-sized block, with worse reverse work. The verified block view and in-block seek address that specific adverse result; old pilot samples remain under `historical/` and are not controlled latency evidence.
- Its point-control median paired ratio was 0.9977 without a composite index and 1.0217 with one. The measured overhead led to query-shape-scoped proof/catalog work. Historical samples remain available; they are not substituted for the final controls.
- A 100k single-transaction fixture refused the unchanged 16 MiB WAL record ceiling before append. It was replaced by bounded transactions, not a larger production allowance.
- Source552 completed the bounded-write OutOfCore pilot with exact results but 909.381 seconds of setup. A retained native sample identifies repeated full-record visits from incremental uniqueness validation. Moving CREATE UNIQUE after loading still reaches `validate_unique_property_streaming`, whose nested full scans also scale poorly. That next attempt was terminated during setup; its partial matrix is explicitly non-final. The final benchmark prepares in Materialized mode and measures reopened OutOfCore reads. These existing write/DDL costs remain unresolved and are excluded from any read speedup claim.

## Reproduction and evidence

From the repository root, build `cargo build --locked --release --bench composite_ordered_seek --jobs 2`, then run the executable under `target/release/deps/` as `<executable> <rows> <fresh-directory-or-dash> 7`. A dash selects resident mode. Use the checked-in point host source with a manifest pointing at the selected library checkout, and build from that checkout root so the pinned compiler and repository profiles apply. Do not mix executables from different heads.

`protocol/` records source hashes, executable hashes, driver, analysis script, build receipts and source-bound local qualification. The measurement driver contains the original absolute receipt paths; adapt those paths for replay, retaining its idle-process, source-cleanliness and binary-hash checks. `SHA256SUMS` covers all evidence files except itself. Binaries and fixture databases are intentionally omitted.

Ordinary regressions run in existing CI lanes. Local source552 Bazel qualification passed 98/98 (12 executed/86 cached, 673.408 seconds including build), with all XML archived; current benchmark-only source reuses all 98 results. Manual MVCC receipts remain source-bound and separate from remote CI. Incremental release benchmark builds took 7m56s at source552 with competing qualification and subsequent benchmark-only rebuild times are in build logs. These are not clean first-build measurements; a clean build cost was not measured. No claim of remote CI speedup follows.

Publication/writer qualification remains with existing Consumer owners. Administrative closure of #232 does not replace its missing performance receipts; #1136 and source-qualified writer/progress gaps are independent. See the [contract](../../specs/COMPOSITE_ORDERED_SEEK_SPEC.md) and [test ownership](../../TEST_INDEX.md).
