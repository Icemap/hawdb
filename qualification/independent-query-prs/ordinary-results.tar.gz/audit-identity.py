"""Verify diagnostic source trees, logging-only overlays and frozen native bytes."""

from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "pr-986-result-accounting-source"
RUN = 38710025204
DISPATCH = "895d1eed239d88992810f74fd6f783b1acf18781"
BASE = "f7c4eb48915b58f5c800491869f93bdb8c0c73da"
FEATURE = "dc73bed5e13c10351e83a3e3b495c9043b41a2a9"
INTEGRATED_TREE = "ec79975524707f7ee9b4b06cbd7ce92ce6e2a7f9"
FILE = "src/api/tests/projected_graph_execution/review_regressions.rs"


def gh(path):
    return json.loads(subprocess.check_output(["gh", "api", path]))


def git(*args, **kwargs):
    return (
        subprocess.check_output(["git", "-C", str(SOURCE), *args], **kwargs)
        .decode()
        .strip()
    )


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stream_sha(stream):
    digest = hashlib.sha256()
    while chunk := stream.read(1024 * 1024):
        digest.update(chunk)
    return digest.hexdigest()


run = gh(f"repos/nowledge-co/hawdb/actions/runs/{RUN}")
assert run["head_sha"] == DISPATCH and run["status"] == "completed"
artifacts = gh(f"repos/nowledge-co/hawdb/actions/runs/{RUN}/artifacts")["artifacts"]
matches = [a for a in artifacts if a["name"] == "identity-diagnostic-" + DISPATCH]
assert len(matches) == 1
artifact = matches[0]
archive = ROOT / "identity-diagnostic.zip"
if not archive.exists():
    temporary = archive.with_suffix(".partial")
    with temporary.open("wb") as stream:
        subprocess.run(
            [
                "gh",
                "api",
                f'repos/nowledge-co/hawdb/actions/artifacts/{artifact["id"]}/zip',
            ],
            stdout=stream,
            check=True,
            timeout=600,
        )
    assert zipfile.is_zipfile(temporary)
    temporary.replace(archive)
with archive.open("rb") as stream:
    archive_sha = stream_sha(stream)
assert artifact["digest"] == "sha256:" + archive_sha
directory = ROOT / "identity-artifact"
directory.mkdir(exist_ok=True)
for recorded_name, source_path in [
    (
        "diagnostic-driver.py",
        "qualification/independent-query-prs/diagnose-identity.py",
    ),
    ("diagnostic-workflow.yml", ".github/workflows/native-bindings.yml"),
]:
    (directory / recorded_name).write_bytes(
        subprocess.check_output(
            ["git", "-C", str(SOURCE), "show", DISPATCH + ":" + source_path]
        )
    )
(directory / "actions-run.json").write_text(json.dumps(run, indent=2) + "\n")
with zipfile.ZipFile(archive) as zipped:
    for member in zipped.infolist():
        path = Path(member.filename)
        assert not path.is_absolute() and ".." not in path.parts
        if member.is_dir() or path.name.endswith("-test-binary"):
            continue
        assert len(path.parts) == 1
        (directory / path).write_bytes(zipped.read(member))
    report = json.loads((directory / "report.json").read_text())
    assert report["terminal"] and len(report["records"]) == 2
    assert (
        report["test"]
        == "api::tests::projected_graph_execution::review_regressions::projected_identity_ignores_large_content_and_rejects_large_ids_without_a_prefix"
    )
    assert set(report["producers"]) == {"baseline", "1036"}
    assert git("merge-tree", "--write-tree", BASE, FEATURE) == INTEGRATED_TREE
    original = subprocess.check_output(
        ["git", "-C", str(SOURCE), "show", BASE + ":" + FILE]
    )
    assert original == subprocess.check_output(
        ["git", "-C", str(SOURCE), "show", FEATURE + ":" + FILE]
    )
    phases = {}
    for name, producer in report["producers"].items():
        production_tree = (
            INTEGRATED_TREE if name == "1036" else git("rev-parse", BASE + "^{tree}")
        )
        assert producer["head"] == BASE
        assert producer["feature_head"] == (FEATURE if name == "1036" else None)
        assert producer["production_tree"] == production_tree
        assert producer["fixture_sha256"] == sha(original)
        logging_patch = directory / (name + "-logging.patch")
        assert sha(logging_patch.read_bytes()) == producer["logging_patch_sha256"]
        assert (
            sha((directory / (name + "-source-overlay.patch")).read_bytes())
            == producer["source_overlay_sha256"]
        )
        with tempfile.TemporaryDirectory(dir=ROOT) as temporary_index:
            environment = {
                **os.environ,
                "GIT_INDEX_FILE": str(Path(temporary_index) / "index"),
            }
            git("read-tree", production_tree, env=environment)
            git("apply", "--cached", str(logging_patch), env=environment)
            measured_tree = git("write-tree", env=environment)
            assert measured_tree == producer["measured_tree"]
        assert git("diff", "--name-only", production_tree, measured_tree) == FILE
        measured = subprocess.check_output(
            ["git", "-C", str(SOURCE), "show", measured_tree + ":" + FILE]
        )
        lines = measured.splitlines(keepends=True)
        diagnostic = [
            line
            for line in lines
            if b"identity-diagnostic stage=" in line
            or b"let diagnostic_started =" in line
        ]
        assert len(diagnostic) == 8
        assert b"".join(line for line in lines if line not in diagnostic) == original
        with zipped.open(name + "-test-binary") as stream:
            assert stream_sha(stream) == producer["binary_sha256"]
        record = next(r for r in report["records"] if r["producer"] == name)
        for suffix in ["stdout", "stderr"]:
            assert (
                sha((directory / (name + "." + suffix)).read_bytes())
                == record[suffix + "_sha256"]
            )
        text = (directory / (name + ".stderr")).read_text()
        events = []
        for line in text.splitlines():
            match = re.search(
                r"identity-diagnostic stage=(\S+)(.*?) elapsed=([0-9.]+)(s|ms|µs|ns)$",
                line,
            )
            if match:
                scale = {"s": 1, "ms": 1e-3, "µs": 1e-6, "ns": 1e-9}[match[4]]
                events.append(
                    {
                        "stage": match[1],
                        "case": match[2].strip(),
                        "elapsed_seconds": float(match[3]) * scale,
                    }
                )
        assert (events or record["timed_out"]) and all(
            a["elapsed_seconds"] <= b["elapsed_seconds"]
            for a, b in zip(events, events[1:])
        )
        if record["process_exit"] == 0 and not record["timed_out"]:
            assert len(events) == 19 and events[-1]["stage"] == "done"
            assert "1 passed; 0 failed" in (directory / (name + ".stdout")).read_text()
        if record["timed_out"]:
            assert 899 <= record["wall_seconds"] <= 930
        phases[name] = {"record": record, "phases": events}
    assert len({p["logging_patch_sha256"] for p in report["producers"].values()}) == 1
receipt = {
    "terminal": True,
    "run": RUN,
    "dispatch": DISPATCH,
    "run_conclusion": run["conclusion"],
    "archive_sha256": archive_sha,
    "artifact": artifact,
    "report_sha256": sha((directory / "report.json").read_bytes()),
    "auditor_sha256": sha(Path(__file__).read_bytes()),
    "scope": "Phase diagnostic only. Complete original fixture/assertions, identical logging-only patch and exact production/measured trees independently verified; both archived frozen binaries hashed. Does not replace root CI acceptance or qualify a performance ratio.",
    "producers": report["producers"],
    "results": phases,
}
(ROOT / "identity-audit.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
