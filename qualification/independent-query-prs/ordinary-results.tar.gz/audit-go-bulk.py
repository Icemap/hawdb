"""Reconstruct frozen Linux Go diagnostic provenance, outcomes and paired ratios."""
from pathlib import Path
import hashlib
import itertools
import json
import re
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "go-bulk-artifact/go-bulk-diagnostic"
CLONE = ROOT.parent / "pr-986-result-accounting-source"
sys.path.insert(0, str(ROOT / "harness/bindings/benchmarks"))
import run as harness

report = json.loads((BASE / "report.json").read_text())
original = json.loads((ROOT / "producers.json").read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def mapped(path):
    return BASE / path.split("/go-bulk-diagnostic/", 1)[1]


assert report["original_run"] == 38695324983
assert report["original_revision"] == "3e5b014e57e4ee58bc99e790a2d495183b87ae48"
assert report["archive_sha256"] == report["original_artifact"]["digest"].split(":", 1)[1]
driver = subprocess.check_output(["git", "-C", str(CLONE), "show", "d496d58f85ab4aaf655a5b549e03455534c93b4a:qualification/independent-query-prs/diagnose-go-bulk.py"])
assert hashlib.sha256(driver).hexdigest() == report["driver_sha256"]
source = (ROOT / "go-bulk-artifact/diagnostic-host/source.txt").read_text().splitlines()
assert source[:2] == ["d496d58f85ab4aaf655a5b549e03455534c93b4a", "87d6baec2ae9bf135f1e4571a0b8d8b8b559cfc3"]
for name, p in report["producers"].items():
    for field in ["head", "base_tree", "measured_tree", "overlay_patch_sha256"]:
        assert p["original_source"][field] == original[name][field]
    for item in p["artifacts"].values():
        assert sha(mapped(item["path"])) == item["sha256"]
for alias, p in report["aliases"].items():
    assert sha(mapped(p["binary"])) == report["producers"][p["producer"]]["artifacts"]["go"]["sha256"]
names = list(report["aliases"])
expected = set(itertools.product([1000, 10000], range(12), names))
observed = {}
for r in report["records"]:
    key = (r["size"], r["iteration"], r["alias"])
    assert key in expected and key not in observed
    count, iteration, alias = key
    assert r["discarded"] == (iteration == 0)
    assert r["order"] == names[iteration % 6:] + names[:iteration % 6]
    assert r["producer"] == report["aliases"][alias]["producer"]
    assert r["command"] == [report["aliases"][alias]["binary"], r["command"][1], report["producers"][r["producer"]]["artifacts"]["library"]["path"]]
    fixture = harness.fixture(count, "fill_bulk")
    fixture_path = BASE / f"fixture-{count}.json"
    assert json.loads(fixture_path.read_text()) == fixture and sha(fixture_path) == r["fixture_sha256"]
    job = mapped(r["command"][1])
    assert sha(job) == r["job_sha256"]
    assert json.loads(job.read_text()) == {**fixture, "backend": "memory", "path": str(Path(r["command"][1]).parent / "db")}
    for stream in ["stdout", "stderr"]:
        assert sha(mapped(r[stream])) == r[stream + "_sha256"]
    raw = json.loads(mapped(r["stdout"]).read_text().splitlines()[-1])
    assert all(r[k] == v for k, v in raw.items())
    assert raw["status"] == "ok" and r["process_exit"] == 0 and r["qualified"] and r["parity"]
    assert raw["output_rows"] == count and raw["checksum"] == fixture["expected_checksum"]
    assert raw["case"] == "fill_bulk" and raw["backend"] == "memory"
    assert raw["durability"] == "SyncOnEveryWrite" and raw["cgo_enabled"] is False and raw["native_profile"] is None
    assert raw["query_boundary_ns"] == raw["write_boundary_ns"] + raw["read_boundary_ns"]
    assert r["phase_timing_valid"] and r["profile_valid"]
    text = mapped(r["stderr"]).read_text()
    rss = re.search(r"Maximum resident set size \(kbytes\):\s*(\d+)", text)
    assert rss and int(rss[1]) * 1024 == r["process_peak_rss_bytes"]
    for field, pattern in [("process_user_seconds", r"User time \(seconds\):\s*([0-9.]+)"), ("process_system_seconds", r"System time \(seconds\):\s*([0-9.]+)")]:
        match = re.search(pattern, text)
        assert match and float(match[1]) == r[field]
    observed[key] = r
assert observed.keys() == expected and report["terminal"] and report["all_paths_succeeded"]
for group in report["groups"]:
    for comparison, metrics in group["comparisons"].items():
        left, right = comparison.split("/")
        for metric, item in metrics.items():
            pairs = [observed[(group["rows"], i, left)][metric] / observed[(group["rows"], i, right)][metric] for i in range(1, 12)]
            median = statistics.median(pairs)
            assert item == {"median_left_over_right": median, "min": min(pairs), "max": max(pairs), "mad": statistics.median(abs(x - median) for x in pairs), "pairs": pairs}
result = {"terminal": True, "records": len(observed), "report_sha256": sha(BASE / "report.json"), "auditor_sha256": sha(Path(__file__)), "groups": report["groups"], "scope": report["scope"]}
(ROOT / "go-bulk-audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ["terminal", "records", "report_sha256", "auditor_sha256"]}, indent=2))
