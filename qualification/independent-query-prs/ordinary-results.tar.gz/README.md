# Independent PR qualification raw evidence

Issue Number: ref #1004, ref #1008, ref #992, ref #1001

This package records the terminal 1k/10k ordinary Linux matrix, the 128-record
mixed-growth control, its 128-record identical-binary A/A diagnostic, and the
144-record frozen Linux Go bulk diagnostic. Exact source heads, measured trees,
overlays, native artifact hashes, raw stdout/stderr, checksums, CPU/RSS and
unfavorable/refused outcomes are preserved with the original independent auditors.
The original #986 full 100k/1M retained/Arrow and comprehensive performance gate
remains open. A refused group has no qualified latency ratio.

Run `python3 -B verify-files.py` after extraction to check package file integrity.
This lightweight command does not repeat the native binary or Git-object checks.
Those checks were performed by the included original auditors and download tools;
their terminal reports are included. Native binaries and copied Python runtimes
are excluded. Complete original Linux artifact ZIPs remain on the linked Actions
runs, and the exact Mac producers remain in the owner's local qualification store.
Original auditor paths refer to that store or recorded runner temporary paths.
Repeated generated Go job JSON is excluded; the canonical fixtures and recorded
commands permit reconstruction of every recorded job hash. All raw outcomes remain.

Original matrix: https://github.com/nowledge-co/hawdb/actions/runs/38695324983
Frozen Go diagnostic: https://github.com/nowledge-co/hawdb/actions/runs/38702906875
Dense identity phase diagnostic: https://github.com/nowledge-co/hawdb/actions/runs/38710025204

The identity diagnostic independently verifies the actual Prow production tree,
the identical logging-only overlay and both native binaries. Main and #1036 both
pass the unchanged exact test in about 403/404 seconds on the same host. This
single pair diagnoses phases; it does not replace complete root CI acceptance
or qualify a performance ratio. The original 900-second Prow timeout is retained
in the PR history. The subsequent unchanged-source complete root recheck passes
58/58, with the identity test actually executing in 523.2 seconds under 900.
Public CI logs, exact source readback and read-only CPU snapshots are included.

The incomplete macOS ordinary attempt and sandboxed mixed attempt remain failed
receipts, without a qualified latency claim. A/A variance does not establish that
adverse A/B outcomes are noise. The documented 1k raw rotating refreshed-hot-read
tradeoff in #1036 remains visible; it does not waive the original full gate.
