# Copyright 2026 Nowledge
# SPDX-License-Identifier: Apache-2.0

"""Build and compare two immutable ordinary-boundary producers on one host."""

import argparse
import hashlib
import itertools
import json
import os
import pathlib
import platform
import re
import shutil
import statistics
import subprocess
import sys

import run as matrix

ROOT = pathlib.Path(__file__).resolve().parents[2]
BASELINE = "3cdb2610ba8b984676b80ba22df64821787886d3"
TARGETS = (
    "//:hawdb_bench_host_boundary", "//bindings/benchmarks:python_boundary",
    "//bindings/go/cmd/boundary", "//bindings/ffi:hawdb_ffi",
)
HARNESS = (
    "benches/host_boundary.rs", "benches/host_boundary/workload.rs",
    "benches/host_boundary/checksum.rs", "bindings/benchmarks/run.py",
    "bindings/benchmarks/checksum.py", "bindings/benchmarks/python_boundary.py",
    "bindings/go/cmd/boundary/BUILD.bazel", "bindings/go/cmd/boundary/main.go",
    "bindings/go/cmd/boundary/profile_unix.go", "bindings/go/cmd/boundary/profile_windows.go",
)
BASELINE_BUILD = '''load("@rules_python//python:defs.bzl", "py_binary", "py_library")
package(default_visibility = ["//visibility:public"])
py_library(name = "checksum", srcs = ["checksum.py"], imports = ["."])
py_binary(name = "python_boundary", srcs = ["python_boundary.py"],
          deps = [":checksum", "//bindings/python:hawdb"], tags = ["manual"])
'''


def command(arguments, cwd):
    return subprocess.check_output(arguments, cwd=cwd, text=True).strip()


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def runfiles_identity(directory):
    entries = []
    for path in sorted(directory.rglob("*")):
        relative = path.relative_to(directory).as_posix()
        if path.is_symlink():
            if not path.resolve(strict=True).is_relative_to(directory.resolve()):
                raise RuntimeError("frozen runfile points outside its tree: " + relative)
            entries.append((relative, "link", os.readlink(path)))
        elif path.is_file():
            entries.append((relative, "file", sha256(path), path.stat().st_mode & 0o777))
        else:
            entries.append((relative, "directory"))
    digest = hashlib.sha256(json.dumps(entries, separators=(",", ":")).encode()).hexdigest()
    return {"path": str(directory), "sha256": digest, "entries": len(entries)}


def manifest_entry(logical, physical):
    def escape(value):
        return value.replace("\\", "\\b").replace("\n", "\\n")
    # Bazel escapes spaces in logical names only; physical paths may contain
    # spaces because the manifest reader splits once at the first separator.
    escaped = escape(logical).replace(" ", "\\s"), escape(physical)
    prefix = " " if escaped != (logical, physical) else ""
    return prefix + escaped[0] + " " + escaped[1] + "\n"


def freeze_python_launcher(original, target):
    source = pathlib.Path(str(original) + ".runfiles")
    destination = pathlib.Path(str(target) + ".runfiles")
    source_manifest = pathlib.Path(str(original) + ".runfiles_manifest")
    manifest_before = sha256(source_manifest)
    links = []

    def ignore(directory, names):
        skipped = []
        for name in names:
            path = pathlib.Path(directory) / name
            if name == "__pycache__" or name.endswith(".pyc") or path == source / "MANIFEST":
                skipped.append(name)
            elif path.is_symlink():
                link = os.readlink(path)
                endpoint = pathlib.Path(os.path.abspath(path.parent / link))
                if not os.path.isabs(link) and endpoint.is_relative_to(source) and endpoint.exists():
                    # Keep the venv interpreter linked to the frozen runtime;
                    # copying it into the venv breaks its library search path.
                    links.append((path.relative_to(source), link))
                    skipped.append(name)
        return skipped

    shutil.copy2(original, target)
    # Absolute/out-of-tree Bazel links must become independent content.
    shutil.copytree(source, destination, ignore=ignore)
    for relative, link in links:
        (destination / relative).symlink_to(link)
    contents = "".join(manifest_entry(path.relative_to(destination).as_posix(), str(path))
                       for path in sorted(destination.rglob("*")))
    (destination / "MANIFEST").write_text(contents)
    pathlib.Path(str(target) + ".runfiles_manifest").write_text(contents)
    if sha256(source_manifest) != manifest_before:
        raise RuntimeError("Python runfiles manifest changed while freezing")
    return runfiles_identity(destination)


def require_producer(producer):
    for name, artifact in producer.items():
        if sha256(pathlib.Path(artifact["path"])) != artifact["sha256"]:
            raise RuntimeError("frozen producer changed: " + name)
    python = producer["python"]
    if runfiles_identity(pathlib.Path(python["runfiles"]["path"])) != python["runfiles"]:
        raise RuntimeError("frozen Python runfiles changed")
    manifest = pathlib.Path(python["path"] + ".runfiles_manifest")
    if sha256(manifest) != python["runfiles_manifest_sha256"]:
        raise RuntimeError("frozen Python runfiles manifest changed")


def validate_revision(revision):
    if not re.fullmatch(r"[0-9a-f]{40}", revision):
        raise ValueError("baseline must be a full immutable Git SHA")
    if revision != BASELINE:
        raise ValueError("baseline adapters are qualified only for " + BASELINE)


def require_source(repository, expected):
    subprocess.run(["git", "diff", "--quiet"], cwd=repository, check=True)
    if command(["git", "ls-files", "--others", "--exclude-standard"], repository):
        raise RuntimeError("source contains untracked files")
    actual = {"head": command(["git", "rev-parse", "HEAD"], repository),
              "tree": command(["git", "write-tree"], repository)}
    if any(actual[key] != expected[key] for key in actual):
        raise RuntimeError("source changed during comparison")


def prepare_baseline(destination, revision):
    validate_revision(revision)
    subprocess.run(["git", "merge-base", "--is-ancestor", revision, "HEAD"], cwd=ROOT, check=True)
    subprocess.run(["git", "clone", "--shared", "--no-checkout", str(ROOT), str(destination)], check=True)
    subprocess.run(["git", "checkout", "--detach", revision], cwd=destination, check=True)
    adapter = ROOT / "bindings/benchmarks/main-baseline-adapters.json"
    specification = json.loads(adapter.read_text())
    if specification["baseline"] != revision:
        raise ValueError("adapter specification does not match the baseline")
    patch = destination.parent / "baseline-adapters.patch"
    patch.write_text("".join(specification["patch_lines"]))
    subprocess.run(["git", "apply", "--check", str(patch)], cwd=destination, check=True)
    subprocess.run(["git", "apply", str(patch)], cwd=destination, check=True)
    for relative in HARNESS:
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / relative, target)
    (destination / "bindings/benchmarks/BUILD.bazel").write_text(BASELINE_BUILD)
    subprocess.run(["git", "add", "--all"], cwd=destination, check=True)
    return {"head": command(["git", "rev-parse", "HEAD"], destination),
            "tree": command(["git", "write-tree"], destination),
            "adapter_patch_sha256": sha256(patch), "adapter_spec_sha256": sha256(adapter),
            "adaptations": ["Identical ordinary harness and manual targets.",
                            "Identical untimed in-memory opening adapter."]}


def build_producer(repository, directory):
    directory.mkdir()
    with (directory / "build.log").open("w") as log:
        subprocess.run(["bazel", "build", "-c", "opt", *TARGETS], cwd=repository,
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    suffix = ".dylib" if sys.platform == "darwin" else ".so"
    paths = {"rust": repository / "bazel-bin/hawdb_bench_host_boundary",
             "python": repository / "bazel-bin/bindings/benchmarks/python_boundary",
             "library": repository / ("bazel-bin/bindings/ffi/libhawdb_ffi" + suffix),
             "python_extension": repository / "bazel-bin/bindings/python/python/hawdb/_hawdb.so"}
    paths["go"] = repository / command(
        ["bazel", "cquery", "-c", "opt", "//bindings/go/cmd/boundary", "--output=files"], repository)
    frozen = {}
    for name, original in paths.items():
        original = original.resolve(strict=True)
        before = sha256(original)
        target = directory / original.name
        runfiles = None
        if name == "python":
            runfiles = freeze_python_launcher(original, target)
        else:
            shutil.copy2(original, target)
        if sha256(original) != before or sha256(target) != before:
            raise RuntimeError("producer changed while freezing " + name)
        frozen[name] = {"path": str(target), "source": str(original), "sha256": before}
        if runfiles is not None:
            frozen[name].update(runfiles=runfiles, runfiles_manifest_sha256=sha256(
                pathlib.Path(str(target) + ".runfiles_manifest")))
    (directory / "manifest.json").write_text(json.dumps(frozen, indent=2) + "\n")
    return frozen


def selection_keys(selection):
    return set(itertools.product(selection.get("layers", []), selection.get("cases", []),
                                 selection.get("sizes", []), selection.get("backends", [])))


def summarize(before, after, expected_keys):
    summaries = []
    keys = set(expected_keys)
    observed = {(r["layer"], r["case"], r["size"], r["backend"])
                for report in (before, after) for r in report["records"]}
    scope_matches = (observed <= keys
                     and all(selection_keys(report) == keys for report in (before, after)))
    # Enumerate the requested matrix, not only groups that survived execution.
    for key in sorted(keys):
        records = [[r for r in report["records"]
                    if (r["layer"], r["case"], r["size"], r["backend"]) == key]
                   for report in (before, after)]
        groups = [[r for r in group if r["discarded"] is False] for group in records]
        warmups = [[r for r in group if r["discarded"] is True] for group in records]
        expected = before["samples"]
        complete = (scope_matches and before["terminal"] is True and after["terminal"] is True
                    and type(expected) is int and expected > 0 and expected == after["samples"]
                    and all(report.get("discarded_iterations") == 1 for report in (before, after))
                    and all(len(group) == expected
                            and {r["iteration"] for r in group} == set(range(1, expected + 1))
                            for group in groups)
                    and all(len(group) == 1 and group[0]["iteration"] == 0 for group in warmups)
                    and all(len(group) == expected + 1
                            and all(type(r["iteration"]) is int and matrix.qualified_record(r)
                                    for r in group) for group in records))
        item = dict(zip(("layer", "case", "size", "backend"), key))
        item.update(qualified=complete, before_samples=len(groups[0]), after_samples=len(groups[1]))
        if complete:
            for metric in ("elapsed_ns", "query_boundary_ns", "write_boundary_ns", "read_boundary_ns"):
                medians = [statistics.median(r[metric] for r in group) for group in groups]
                item[metric + "_median_speedup"] = medians[0] / medians[1] if medians[1] else None
        summaries.append(item)
    return summaries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--baseline", default=BASELINE)
    parser.add_argument("--sizes", default="1000,100000,1000000")
    parser.add_argument("--cases", default=",".join(matrix.CASES))
    parser.add_argument("--backends", default="memory,file")
    parser.add_argument("--layers", default="rust,python,go")
    parser.add_argument("--samples", type=int, default=3)
    args = parser.parse_args()
    validate_revision(args.baseline)
    if (args.samples < 1 or any(int(size) < 1 for size in args.sizes.split(","))
            or set(args.cases.split(",")) - set(matrix.CASES)
            or set(args.backends.split(",")) - {"memory", "file"}):
        parser.error("positive sizes/samples and known cases/backends are required")
    layers = args.layers.split(",")
    if set(layers) - {"rust", "python", "go"} or len(set(layers)) != len(layers):
        parser.error("known, distinct layers are required")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    evidence = output / "evidence"
    evidence.mkdir()
    source = matrix.source_identity()
    baseline_repository = output / "baseline"
    baseline_source = prepare_baseline(baseline_repository, args.baseline)
    sources = {"baseline": baseline_source, "candidate": source}
    producers = {}
    # Finish all compilation before measuring either version. Never compare
    # ordinary latency against an allocation-instrumented artifact.
    for name, repository in (("baseline", baseline_repository), ("candidate", ROOT)):
        require_source(repository, sources[name])
        print(name, "building optimized producer", flush=True)
        producers[name] = build_producer(repository, evidence / (name + "-producer"))
        require_source(repository, sources[name])
    identity = {"sources": sources, "producers": producers, "platform": platform.platform(),
                "matrix_selection": {"sizes": args.sizes, "cases": args.cases,
                                     "layers": layers, "backends": args.backends,
                                     "samples": args.samples},
                "build": "default Bazel configuration, -c opt", "defaults_changed": False,
                "ordering": "baseline then candidate; ratios of medians, not alternated pairs",
                "measurement_limits": ["Process RSS includes fixture/setup/host runtime.",
                                       "A shard does not establish complete matrix coverage.",
                                       "Ordinary APIs do not use Arrow or retained cursors.",
                                       "Python launcher, package and runtime are copied independently; runfiles hashes are checked before and after each producer matrix.",
                                       "Any refusal/failure prevents a group speedup claim."]}
    for producer in producers.values():
        require_producer(producer)
    (evidence / "manifest.json").write_text(json.dumps(identity, indent=2) + "\n")
    shutil.copyfile(ROOT / "bindings/benchmarks/main-baseline-adapters.json", evidence / "baseline-adapters.json")
    statuses = {}
    reports = {}
    for name, repository in (("baseline", baseline_repository), ("candidate", ROOT)):
        require_source(repository, sources[name])
        producer = producers[name]
        require_producer(producer)
        arguments = [sys.executable, "-B", str(repository / "bindings/benchmarks/run.py"),
                     "--output", str(evidence / name), "--sizes", args.sizes, "--cases", args.cases,
                     "--backends", args.backends, "--layers", args.layers,
                     "--samples", str(args.samples)]
        for flag in ("rust", "python", "go", "library", "python_extension"):
            arguments += ["--" + flag.replace("_", "-"), producer[flag]["path"]]
        with (evidence / (name + "-driver.log")).open("w") as log:
            statuses[name] = subprocess.run(arguments, cwd=repository, stdout=log, stderr=subprocess.STDOUT).returncode
        report_path = evidence / name / "report.json"
        if report_path.exists():
            reports[name] = json.loads(report_path.read_text())
            if reports[name]["source"] != {key: sources[name][key] for key in ("head", "tree")}:
                raise RuntimeError("matrix source does not match the frozen producer")
        require_source(repository, sources[name])
        require_producer(producer)
        print(name, "driver exit", statuses[name], flush=True)
    identity["driver_exits"] = statuses
    if len(reports) == 2:
        requested = selection_keys({"sizes": [int(size) for size in args.sizes.split(",")],
                                    "cases": args.cases.split(","), "layers": layers,
                                    "backends": args.backends.split(",")})
        identity["groups"] = summarize(reports["baseline"], reports["candidate"], requested)
    identity["all_paths_succeeded"] = (
        len(reports) == 2 and all(status == 0 for status in statuses.values())
        and all(report.get("terminal") and report.get("all_paths_succeeded") for report in reports.values())
        and bool(identity.get("groups")) and all(group["qualified"] for group in identity["groups"])
    )
    (evidence / "comparison.json").write_text(json.dumps(identity, indent=2) + "\n")
    raise SystemExit(0 if identity["all_paths_succeeded"] else 1)


if __name__ == "__main__":
    main()
