"""Download completed shard artifacts and verify frozen binary bytes in the ZIP."""

from pathlib import Path
import concurrent.futures, hashlib, json, subprocess, zipfile

ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT / "linux-artifacts"
ARTIFACTS.mkdir(exist_ok=True)
ZIPS = ROOT / "linux-zips"
ZIPS.mkdir(exist_ok=True)
r = subprocess.run(
    [
        "gh",
        "api",
        "repos/nowledge-co/hawdb/actions/runs/38695324983/artifacts?per_page=100",
    ],
    capture_output=True,
    text=True,
    check=True,
    timeout=45,
)
metadata = json.loads(r.stdout)
(ROOT / "linux-artifacts-api.json").write_text(r.stdout)


def digest_stream(stream):
    h = hashlib.sha256()
    while True:
        b = stream.read(1024 * 1024)
        if not b:
            break
        h.update(b)
    return h.hexdigest()


def fetch(a):
    name = a["name"]
    need_prefix = "ordinary-"
    if not name.startswith(need_prefix):
        return
    directory = ARTIFACTS / name
    if (directory / "download-receipt.json").exists():
        return
    archive = ZIPS / (name + ".zip")
    if not archive.exists():
        temporary = archive.with_suffix(".partial")
        token = subprocess.check_output(["gh", "auth", "token"], text=True).strip()
        assert token and "\n" not in token and '"' not in token
        subprocess.run(
            [
                "curl",
                "--disable",
                "--location",
                "--fail",
                "--retry",
                "3",
                "--retry-all-errors",
                "--connect-timeout",
                "20",
                "--max-time",
                "1800",
                "--continue-at",
                "-",
                "--silent",
                "--show-error",
                "--proto",
                "=https",
                "--proto-redir",
                "=https",
                "--config",
                "-",
                "--output",
                str(temporary),
                f'https://api.github.com/repos/nowledge-co/hawdb/actions/artifacts/{a["id"]}/zip',
            ],
            input=f'header = "Authorization: Bearer {token}"\n',
            text=True,
            check=True,
            timeout=1900,
        )
        assert zipfile.is_zipfile(temporary), "download is not a ZIP"
        with temporary.open("rb") as stream:
            actual_archive_sha = digest_stream(stream)
        assert a["digest"] == "sha256:" + actual_archive_sha
        temporary.replace(archive)
    directory.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        names = set(z.namelist())
        assert "producers.json" in names, sorted(names)[:12]
        producers = json.loads(z.read("producers.json"))
        verified = {}
        for producer, p in producers.items():
            for kind, item in p["artifacts"].items():
                relative = producer + "-producer/" + Path(item["path"]).name
                with z.open(relative) as f:
                    actual = digest_stream(f)
                assert actual == item["sha256"], (name, producer, kind)
                verified[producer + "/" + kind] = actual
                if kind == "python":
                    manifest = relative + ".runfiles_manifest"
                    assert (
                        hashlib.sha256(z.read(manifest)).hexdigest()
                        == item["runfiles_manifest_sha256"]
                    )
        for member in z.infolist():
            path = Path(member.filename)
            assert not path.is_absolute() and ".." not in path.parts
            if member.is_dir():
                continue
            first = path.parts[0]
            if first.endswith("-producer"):
                keep = path.name in ["manifest.json", "build.log"] or str(
                    path
                ).endswith(".runfiles_manifest")
            elif first == "ordinary":
                keep = (
                    path.name == "report.json"
                    or path.name.startswith("fixture-")
                    or path.suffix in [".stdout", ".stderr"]
                )
            elif first == "preflight":
                keep = True
            else:
                keep = True
            if keep:
                target = directory / path
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(member))
        receipt = {
            "artifact": a,
            "download_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
            "frozen_binary_hashes_verified": verified,
            "archive": str(archive),
            "extraction": "Complete manifests/source/raw CPU/RSS/results, excluding copied runtimes/binaries and fixture database files. Complete original ZIP is retained.",
        }
        (directory / "download-receipt.json").write_text(
            json.dumps(receipt, indent=2) + "\n"
        )
    print(
        "DOWNLOADED",
        name,
        a["size_in_bytes"],
        "verified native artifacts",
        len(verified),
        flush=True,
    )


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(fetch, metadata["artifacts"]):
        pass
print("AVAILABLE_ARTIFACTS", len(metadata["artifacts"]), flush=True)
