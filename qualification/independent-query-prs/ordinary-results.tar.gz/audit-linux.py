"""Audit the requested Linux shard matrix from source-bound raw artifacts."""
from pathlib import Path
import collections
import functools
import hashlib
import itertools
import json
import re
import statistics
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/"harness/bindings/benchmarks"))
import run as matrix
@functools.lru_cache(maxsize=None)
def expected_fixture(count,case):
 return matrix.fixture(count,case)
HEADS=json.loads((ROOT/"selection.json").read_text())
LOCAL=json.loads((ROOT/"producers.json").read_text())
BASE=ROOT/"linux-artifacts"
OUTPUT=ROOT/"linux-audit.json"
NAMES=["baseline","1028","1029","1036"]
REVISION='3e5b014e57e4ee58bc99e790a2d495183b87ae48'
CLONE=ROOT.parent/'pr-986-result-accounting-source'
PREFIX='qualification/independent-query-prs/'
source_paths=subprocess.check_output(['git','-C',str(CLONE),'ls-tree','-r','--name-only',REVISION,PREFIX],text=True).splitlines()
source_bytes={p[len(PREFIX):]:subprocess.check_output(['git','-C',str(CLONE),'show',REVISION+':'+p]) for p in source_paths}
CASES=["select","point","fill","fill_bulk","wide"]
BACKENDS=["memory","file"]
LAYERS=["rust","python","go"]
requested=set(itertools.product(NAMES,LAYERS,CASES,[1000,10000],BACKENDS,range(8)))
records={};shards=[];errors=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(value,message):
 if not value:raise AssertionError(message)
def local_path(directory,absolute):
 marker='/qualification/'
 need(marker in absolute,'unexpected artifact path '+absolute)
 return directory/absolute.split(marker,1)[1]
for directory in sorted(BASE.glob('ordinary-*')):
 try:
  selection=json.loads((directory/'selection.json').read_text());report=json.loads((directory/'ordinary/report.json').read_text());producers=json.loads((directory/'producers.json').read_text())
  case=selection['ordinary']['cases'];backend=selection['ordinary']['backends']
  need(len(case)==len(backend)==1,'shard selection must be singular')
  need(case[0] in CASES and backend[0] in BACKENDS,'unknown shard')
  need(selection['ordinary']['sizes']==[1000,10000] and selection['ordinary']['layers']==LAYERS,'scope changed')
  need(selection['ordinary']['measured_rounds']==7 and selection['ordinary']['discarded_rounds']==1,'sample count changed')
  expected_selection=json.loads(source_bytes['selection.json'])
  expected_selection['full_matrix']=json.loads(json.dumps(expected_selection['ordinary']))
  expected_selection['ordinary']['cases']=case;expected_selection['ordinary']['backends']=backend
  need(selection==expected_selection,'selection differs from dispatched source')
  for path,data in source_bytes.items():
   if path!='selection.json':need((directory/path).read_bytes()==data,'qualification tool/source changed '+path)
  need(report['selection']==selection['ordinary'],'report scope changed')
  need(report['producers_sha256']==sha(directory/'producers.json'),'producer manifest changed')
  need(report['driver_sha256']==sha(directory/'ordinary.py'),'driver source changed')
  need((directory/'qualification-revision.txt').read_text().strip()==REVISION,'qualification source changed')
  receipt=json.loads((directory/'download-receipt.json').read_text())
  need(receipt['artifact']['workflow_run']['head_sha']==REVISION,'artifact workflow source changed')
  need(receipt['download_sha256']==receipt['artifact']['digest'].split(':',1)[1],'archive digest differs from GitHub artifact')
  need(len(receipt['frozen_binary_hashes_verified'])==20,'frozen binary verification incomplete')
  for name in NAMES:
   p=producers[name];need(p['head']==HEADS[name],'source head changed '+name)
   for field in ['base_tree','measured_tree','overlay_patch_sha256']:
    need(p[field]==LOCAL[name][field],f'{name} {field} differs from independently frozen source')
   need(sha(directory/(name+'-overlay.patch'))==p['overlay_patch_sha256'],'overlay bytes changed')
   for kind,item in p['artifacts'].items():need(receipt['frozen_binary_hashes_verified'][name+'/'+kind]==item['sha256'],'frozen binary receipt differs')
   for path,digest in p['harness'].items():need(sha(directory/'harness'/path)==digest,'built harness differs '+path)
  preflight=json.loads((directory/'preflight/report.json').read_text());need(len(preflight)==12,'incomplete preflight')
  expected_smoke=expected_fixture(1,'point')['expected_checksum']
  for p in preflight:need(p['status']=='ok' and p['process_exit']==0 and p['output_rows']==1 and p['checksum']==expected_smoke,'language preflight failed')
  shard_keys=set(itertools.product(NAMES,LAYERS,case,[1000,10000],backend,range(8)))
  observed=set()
  for r in report['records']:
   key=(r['producer'],r['layer'],r['case'],r['size'],r['backend'],r['iteration'])
   need(key in shard_keys and key not in observed and key not in records,'unexpected/duplicate matrix record')
   observed.add(key)
   need(r['discarded']==(r['iteration']==0),'discard flag changed')
   order=NAMES[r['iteration']%4:]+NAMES[:r['iteration']%4]
   need(r['order']==order,'producer order did not rotate')
   artifact=producers[r['producer']]['artifacts']
   command=[artifact[r['layer']]['path'],r['command'][1]]
   if r['layer']=='go':command.append(artifact['library']['path'])
   if r['layer']=='python':command.append(artifact['python_extension']['path'])
   need(r['command']==command,'command does not use frozen producer')
   path_name={'baseline':'baseline00','1028':'pr10280000','1029':'pr10290000','1036':'pr10360000'}[r['producer']]
   need(Path(r['command'][1]).parts[-3:]==(f'{r["layer"]}-{r["case"]}-{r["size"]}-{r["backend"]}-{r["iteration"]}',path_name,'job.json'),'fresh independent path changed')
   fixture=expected_fixture(r['size'],r['case'])
   canonical=directory/'ordinary'/f'fixture-{r["case"]}-{r["size"]}.json'
   need(sha(canonical)==r['fixture_sha256'],'fixture hash changed')
   need(json.loads(canonical.read_text())==fixture,'fixture data changed')
   need(r['expected_checksum']==fixture['expected_checksum'],'checksum oracle changed')
   job={**fixture,'backend':r['backend'],'path':str(Path(r['command'][1]).parent/'db')}
   expected_job=hashlib.sha256(json.dumps(job,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
   need(expected_job==r['job_sha256'],'job hash or fresh path changed')
   stdout=local_path(directory,r['stdout']);stderr=local_path(directory,r['stderr'])
   need(stdout.is_file() and stderr.is_file(),'missing raw outcome')
   lines=stdout.read_text().splitlines()
   if r['status']=='ok':
    raw=json.loads(lines[-1])
    for field in ['status','case','backend','output_rows','checksum','query_boundary_ns','write_boundary_ns','read_boundary_ns','elapsed_ns','native_profile','durability']:
     need(raw[field]==r[field],'raw outcome differs '+field)
    need(raw['durability']=='SyncOnEveryWrite','durability changed')
    if r['layer']=='go':need(raw['cgo_enabled'] is False,'Go producer changed mode')
    else:need(raw['prefetch']==0,'prefetch changed')
    need(r['process_exit']==0 and r['output_rows']==r['size'] and r['checksum']==fixture['expected_checksum'],'parity failure')
    need(r['query_boundary_ns']==r['write_boundary_ns']+r['read_boundary_ns'],'phase sum mismatch')
    need(r['native_profile'] is None and r['profile_valid'] is True and r['phase_timing_valid'] is True and r['qualified'] is True,'instrumented or invalid ordinary sample')
   else:
    need(not r['qualified'],'failed outcome mislabeled')
   text=stderr.read_text();rss=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text)
   user=re.search(r'User time \(seconds\):\s*([0-9.]+)',text);system=re.search(r'System time \(seconds\):\s*([0-9.]+)',text)
   need(rss and user and system,'missing raw CPU/RSS')
   need(r['process_peak_rss_bytes']==int(rss[1])*1024,'RSS units/value changed')
   need(r['process_user_seconds']==float(user[1]) and r['process_system_seconds']==float(system[1]),'CPU values changed')
   records[key]=r
  need(report['terminal'] is True and observed==shard_keys and len(report['records'])==192,'incomplete shard')
  need(report['all_paths_succeeded']==all(r['qualified'] for r in report['records']),'success flag changed')
  shards.append({'case':case[0],'backend':backend[0],'records':len(observed),'report_sha256':sha(directory/'ordinary/report.json'),'all_paths_succeeded':report['all_paths_succeeded']})
 except Exception as e:errors.append({'artifact':directory.name,'error':str(e)})
comparisons=[]
for layer,case,count,backend in itertools.product(LAYERS,CASES,[1000,10000],BACKENDS):
 for candidate in NAMES[1:]:
  sample={name:[records.get((name,layer,case,count,backend,i)) for i in range(8)] for name in ['baseline',candidate]}
  complete=all(all(r is not None for r in rows) for rows in sample.values())
  item={'candidate':candidate,'layer':layer,'case':case,'size':count,'backend':backend,'complete':complete,'qualified':complete and all(r['qualified'] for rows in sample.values() for r in rows)}
  if item['qualified']:
   for metric in ['query_boundary_ns','read_boundary_ns','write_boundary_ns','elapsed_ns','process_peak_rss_bytes','process_user_seconds','process_system_seconds']:
    ratios=[a[metric]/b[metric] for a,b in zip(sample['baseline'][1:],sample[candidate][1:]) if b[metric]>0]
    if ratios:
     median=statistics.median(ratios);item[metric]={'median_baseline_over_candidate':median,'minimum':min(ratios),'maximum':max(ratios),'mad':statistics.median(abs(x-median) for x in ratios),'samples':len(ratios)}
  elif complete:
   item['outcomes']={name:[{'iteration':r['iteration'],'status':r['status'],'error':r.get('error'),'phase':r.get('phase')} for r in rows if not r['qualified']] for name,rows in sample.items()}
  comparisons.append(item)
missing=requested-set(records)
result={'terminal':not missing and not errors and len(shards)==10,'requested_records':len(requested),'observed_records':len(records),'missing_records':len(missing),'shards':shards,'errors':errors,'status_counts':{str(k):v for k,v in collections.Counter((r['producer'],r['layer'],r['status']) for r in records.values()).items()},'comparisons':comparisons,'auditor_sha256':sha(Path(__file__)),'scope':'Requested 1k/10k independent-PR ordinary matrix; each paired comparison stays on one Linux shard. Budget refusals and regressions remain visible. This does not qualify the original 986 full retained/Arrow gate.'}
OUTPUT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['terminal','requested_records','observed_records','missing_records','errors']},indent=2))
