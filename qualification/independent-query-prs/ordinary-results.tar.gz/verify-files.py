"""Verify package integrity; native binaries and Git objects are external."""
from pathlib import Path
import hashlib
import json
root = Path(__file__).resolve().parent
manifest = json.loads((root / "files.json").read_text())
for name, digest in manifest.items():
    path = root / name
    assert path.is_file(), name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
print("Verified package files:", len(manifest))
print("Native binary and Git-object checks are recorded in the original audit receipts.")
