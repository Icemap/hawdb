"""Stage or freeze only the owned mixed-growth qualification overlay."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent.parent / "pr-986-result-accounting-source"
HEADS = json.loads((ROOT.parent / "selection.json").read_text())
MANIFEST = ROOT / "producers.json"


def command(*args):
    return subprocess.check_output(args, cwd=SOURCE, text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


action, name = sys.argv[1:3]
revision = HEADS[name]
patch = ROOT / (name + "-overlay.patch")
if action == "stage":
    assert not command("git", "status", "--porcelain")
    subprocess.run(["git", "checkout", "--detach", revision], cwd=SOURCE, check=True)
    subprocess.run(["git", "apply", "--index", str(ROOT / "baseline-overlay.patch")], cwd=SOURCE, check=True)
    patch.write_bytes(subprocess.check_output(["git", "diff", "--cached", "--binary", revision], cwd=SOURCE))
    print(name, "staged", command("git", "write-tree"))
elif action == "freeze":
    assert command("git", "rev-parse", "HEAD") == revision
    expected = subprocess.check_output(["git", "diff", "--cached", "--binary", revision], cwd=SOURCE)
    assert expected == patch.read_bytes()
    subprocess.run(["git", "diff", "--exit-code"], cwd=SOURCE, check=True)
    assert not command("git", "ls-files", "--others", "--exclude-standard")
    original = (SOURCE / "bazel-bin/hawdb_bench_mixed_point_growth").resolve(strict=True)
    before = sha(original)
    frozen = ROOT / (name + "-producer")
    if not frozen.exists():
        shutil.copy2(original, frozen)
    assert before == sha(original) == sha(frozen)
    invocation = sys.argv[3]
    records = json.loads(MANIFEST.read_text()) if MANIFEST.exists() else {}
    records[name] = {
        "head": revision,
        "base_tree": command("git", "rev-parse", "HEAD^{tree}"),
        "measured_tree": command("git", "write-tree"),
        "overlay_patch_sha256": sha(patch),
        "probe_sha256": sha(ROOT / "mixed_point_growth.rs"),
        "binary": str(frozen),
        "binary_sha256": before,
        "build": "bazel build -c opt //:hawdb_bench_mixed_point_growth; default configuration",
        "build_invocation_id": invocation,
        "build_verification": "Tool returned exit 0 and Build completed successfully before freezing. Initial sandbox failure remains in baseline-build.log.",
    }
    MANIFEST.write_text(json.dumps(records, indent=2) + "\n")
    subprocess.run(["git", "apply", "-R", "--index", str(patch)], cwd=SOURCE, check=True)
    assert not command("git", "status", "--porcelain")
    print(name, "frozen and source restored", before)
else:
    raise ValueError(action)
