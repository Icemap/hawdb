"""Reconstruct mixed-growth outcomes and ratios from exact-source raw receipts."""
from pathlib import Path
import hashlib
import itertools
import json
import re
import statistics
import subprocess

ROOT = Path(__file__).resolve().parent
CLONE = ROOT.parent.parent / "pr-986-result-accounting-source"
REPORT = ROOT / "outside-sandbox/report.json"
data = json.loads(REPORT.read_text())
producers = json.loads((ROOT / "producers.json").read_text())
selection = json.loads((ROOT.parent / "selection.json").read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(CLONE), *args])


assert data["driver_sha256"] == sha(ROOT / "paired.py")
assert data["producers"] == producers
source = (ROOT / "mixed_point_growth.rs").read_bytes()
for name, p in producers.items():
    assert p["head"] == selection[name]
    assert p["base_tree"] == git("rev-parse", p["head"] + "^{tree}").decode().strip()
    assert sha(Path(p["binary"])) == p["binary_sha256"]
    assert sha(ROOT / (name + "-overlay.patch")) == p["overlay_patch_sha256"]
    assert sha(ROOT / "mixed_point_growth.rs") == p["probe_sha256"]
    assert git("show", p["measured_tree"] + ":benches/mixed_point_growth.rs") == source
    original = git("show", p["head"] + ":benchmarks.bzl")
    expected = original.replace(b"HAWDB_MANUAL_BENCHMARKS = [\n", b'HAWDB_MANUAL_BENCHMARKS = [\n    "mixed_point_growth",\n')
    assert git("show", p["measured_tree"] + ":benchmarks.bzl") == expected
    assert set(git("diff", "--name-only", p["base_tree"], p["measured_tree"]).decode().splitlines()) == {"benchmarks.bzl", "benches/mixed_point_growth.rs"}
requested = set(itertools.product([1000, 10000], ["raw", "admitted"], ["stable", "rotating"], range(8), ["baseline", "1036"]))
observed = {}
errors = []
for record in data["records"]:
    key = (record["requested_rows"], record["requested_api"], record["requested_parameter_mode"], record["iteration"], record["producer"])
    assert key in requested and key not in observed
    rows, api, mode, iteration, producer = key
    assert record["discarded"] == (iteration == 0)
    assert record["command"] == [producers[producer]["binary"], str(rows), "-", api, mode]
    for stream in ["stdout", "stderr"]:
        assert sha(Path(record[stream])) == record[stream + "_sha256"]
    raw = json.loads(Path(record["stdout"]).read_text().splitlines()[-1])
    for field, value in raw.items():
        assert record[field] == value, field
    qualified = record["process_exit"] == 0 and raw["status"] == "ok"
    if qualified:
        assert (raw["rows"], raw["api"], raw["parameter_mode"], raw["backend"]) == (rows, api, mode, "memory")
        assert raw["initial_rows"] == 4 and raw["independent_growth_statements"] == rows - 4
        assert raw["point_calls_per_phase"] == 100 and raw["durability"] == "SyncOnEveryWrite"
        assert len(raw["hot_ns"]) == len(raw["refreshed_ns"]) == 100
        assert all(type(t) is int and t >= 0 for t in raw["hot_ns"] + raw["refreshed_ns"])
        assert record["first_hot_ns"] == raw["hot_ns"][0]
        assert record["total_hot_ns"] == sum(raw["hot_ns"])
        assert record["hot_median_ns"] == statistics.median(raw["hot_ns"])
        assert record["refreshed_median_ns"] == statistics.median(raw["refreshed_ns"])
        assert record["hot_p95_ns"] == sorted(raw["hot_ns"])[94]
        assert record["hot_p99_ns"] == sorted(raw["hot_ns"])[98]
        assert "access=SeqNodeScan" in raw["initial_plan"]
        assert "access=IndexNodeSeek" in raw["after_hot_diagnostic_plan"]
        assert "access=IndexNodeSeek" in raw["refreshed_plan"]
        text = Path(record["stderr"]).read_text()
        rss = re.search(r"(\d+)\s+maximum resident set size", text)
        cpu = re.search(r"([0-9.]+) real\s+([0-9.]+) user\s+([0-9.]+) sys", text)
        assert rss and cpu and "Operation not permitted" not in text
        assert int(rss[1]) == record["process_peak_rss_bytes"]
    assert record["qualified"] == qualified
    if not qualified:
        errors.append({"key": list(key), "status": record["status"], "process_exit": record["process_exit"]})
    observed[key] = record
groups = []
for rows, api, mode in itertools.product([1000, 10000], ["raw", "admitted"], ["stable", "rotating"]):
    keys = set(itertools.product([rows], [api], [mode], range(8), ["baseline", "1036"]))
    group = {"rows": rows, "api": api, "parameter_mode": mode, "complete": keys <= observed.keys()}
    group["qualified"] = group["complete"] and all(observed[k]["qualified"] for k in keys)
    if group["qualified"]:
        group["ratios"] = {}
        for metric in ["growth_ns", "first_hot_ns", "total_hot_ns", "hot_median_ns", "hot_p95_ns", "hot_p99_ns", "refreshed_median_ns", "process_peak_rss_bytes"]:
            pairs = [observed[(rows, api, mode, i, "baseline")][metric] / observed[(rows, api, mode, i, "1036")][metric] for i in range(1, 8)]
            median = statistics.median(pairs)
            item = {"median_baseline_over_candidate": median, "min": min(pairs), "max": max(pairs), "mad": statistics.median(abs(t - median) for t in pairs), "pairs": pairs}
            group["ratios"][metric] = item
            if data["terminal"]:
                original = next(g for g in data["groups"] if (g["rows"], g["api"], g["parameter_mode"]) == (rows, api, mode))
                assert item == original["ratios"][metric]
    groups.append(group)
result = {"terminal": observed.keys() == requested, "requested_records": len(requested), "observed_records": len(observed), "errors": errors, "groups": groups, "report_sha256": sha(REPORT), "auditor_sha256": sha(Path(__file__)), "scope": data["scope"]}
(ROOT / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ["terminal", "requested_records", "observed_records", "errors"]}, indent=2))
