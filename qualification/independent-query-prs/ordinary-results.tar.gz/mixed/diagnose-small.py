"""Repeat adverse 1k mixed controls with paired A/B and identical-binary A/A aliases."""
from pathlib import Path
import hashlib
import itertools
import json
import os
import re
import statistics
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "small-diagnostic"
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT.parent / "harness/bindings/benchmarks"))
import run as harness

original = json.loads((ROOT / "producers.json").read_text())
producers = {}
for alias, source in [("baselineA", "baseline"), ("baselineB", "baseline"), ("candidata", "1036"), ("candidatb", "1036")]:
    destination = OUT / alias
    os.link(original[source]["binary"], destination)
    producers[alias] = {"source": source, "binary": str(destination), "sha256": original[source]["binary_sha256"]}
report = {"terminal": False, "producers": producers, "source_producers": original, "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "records": [], "scope": "Diagnostic of observed adverse 1k mixed-growth samples. Four rotating aliases: baseline A/B share identical binary bytes and candidate A/B share identical binary bytes. Original raw/admitted, stable/rotating, 100-query phases and defaults are unchanged; one discarded plus seven measured rounds. A/A variation does not establish that adverse A/B samples are noise or close the original performance gate."}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def guard():
    for item in producers.values():
        assert sha(Path(item["binary"])) == item["sha256"]


def save():
    (OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")


names = list(producers)
for mode in ["stable", "rotating"]:
    for iteration in range(8):
        apis = ["raw", "admitted"] if iteration % 2 == 0 else ["admitted", "raw"]
        order = names[iteration % 4:] + names[:iteration % 4]
        for api in apis:
            for name in order:
                guard()
                prefix = OUT / f"{api}-{mode}-{iteration}-{name}"
                record = harness.run_child([producers[name]["binary"], "1000", "-", api, mode], prefix)
                record.update(producer=name, iteration=iteration, discarded=iteration == 0, requested_api=api, requested_parameter_mode=mode, order=order)
                record["qualified"] = bool(record["status"] == "ok" and record["process_exit"] == 0 and record.get("rows") == 1000 and record.get("api") == api and record.get("parameter_mode") == mode and record.get("durability") == "SyncOnEveryWrite" and len(record.get("hot_ns", [])) == len(record.get("refreshed_ns", [])) == 100)
                if record["qualified"]:
                    record.update(first_hot_ns=record["hot_ns"][0], hot_median_ns=statistics.median(record["hot_ns"]), hot_p95_ns=sorted(record["hot_ns"])[94], hot_p99_ns=sorted(record["hot_ns"])[98], total_hot_ns=sum(record["hot_ns"]), refreshed_median_ns=statistics.median(record["refreshed_ns"]))
                for stream in ["stdout", "stderr"]:
                    record[stream + "_sha256"] = sha(Path(record[stream]))
                report["records"].append(record)
                save()
                guard()
                print(api, mode, iteration, name, record["qualified"], flush=True)
report["groups"] = []
for api, mode in itertools.product(["raw", "admitted"], ["stable", "rotating"]):
    selected = [r for r in report["records"] if (r["requested_api"], r["requested_parameter_mode"]) == (api, mode)]
    assert len(selected) == 32
    group = {"api": api, "parameter_mode": mode, "qualified": all(r["qualified"] for r in selected), "comparisons": {}}
    if group["qualified"]:
        for left, right in [("baselineA", "candidata"), ("baselineB", "candidatb"), ("baselineA", "baselineB"), ("candidata", "candidatb")]:
            metrics = {}
            for metric in ["growth_ns", "first_hot_ns", "hot_median_ns", "hot_p95_ns", "hot_p99_ns", "refreshed_median_ns", "process_peak_rss_bytes"]:
                pairs = []
                for iteration in range(1, 8):
                    pair = {r["producer"]: r for r in selected if r["iteration"] == iteration}
                    pairs.append(pair[left][metric] / pair[right][metric])
                median = statistics.median(pairs)
                metrics[metric] = {"median_left_over_right": median, "min": min(pairs), "max": max(pairs), "mad": statistics.median(abs(x - median) for x in pairs), "pairs": pairs}
            group["comparisons"][left + "/" + right] = metrics
    report["groups"].append(group)
report["terminal"] = len(report["records"]) == 128
report["all_paths_succeeded"] = all(r["qualified"] for r in report["records"])
save()
print("TERMINAL", len(report["records"]), report["all_paths_succeeded"], flush=True)
