"""Audit the fixed-size A/A and A/B diagnostic without discarding adverse samples."""
from pathlib import Path
import hashlib
import itertools
import json
import re
import statistics

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "small-diagnostic"
report = json.loads((OUT / "report.json").read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert report["driver_sha256"] == sha(ROOT / "diagnose-small.py")
assert report["source_producers"] == json.loads((ROOT / "producers.json").read_text())
for alias, p in report["producers"].items():
    assert p["sha256"] == report["source_producers"][p["source"]]["binary_sha256"]
    assert sha(Path(p["binary"])) == p["sha256"]
assert report["producers"]["baselineA"]["sha256"] == report["producers"]["baselineB"]["sha256"]
assert report["producers"]["candidata"]["sha256"] == report["producers"]["candidatb"]["sha256"]
names = list(report["producers"])
expected = set(itertools.product(["raw", "admitted"], ["stable", "rotating"], range(8), names))
observed = {}
for r in report["records"]:
    key = (r["requested_api"], r["requested_parameter_mode"], r["iteration"], r["producer"])
    assert key in expected and key not in observed
    api, mode, i, alias = key
    assert r["order"] == names[i % 4:] + names[:i % 4]
    assert r["command"] == [report["producers"][alias]["binary"], "1000", "-", api, mode]
    for stream in ["stdout", "stderr"]:
        assert sha(Path(r[stream])) == r[stream + "_sha256"]
    raw = json.loads(Path(r["stdout"]).read_text().splitlines()[-1])
    assert all(r[k] == v for k, v in raw.items())
    assert raw["status"] == "ok" and r["process_exit"] == 0 and r["qualified"]
    assert (raw["rows"], raw["initial_rows"], raw["independent_growth_statements"], raw["point_calls_per_phase"]) == (1000, 4, 996, 100)
    assert (raw["api"], raw["parameter_mode"], raw["backend"], raw["durability"]) == (api, mode, "memory", "SyncOnEveryWrite")
    assert len(raw["hot_ns"]) == len(raw["refreshed_ns"]) == 100
    assert r["first_hot_ns"] == raw["hot_ns"][0]
    assert r["hot_median_ns"] == statistics.median(raw["hot_ns"])
    assert r["hot_p95_ns"] == sorted(raw["hot_ns"])[94]
    assert r["hot_p99_ns"] == sorted(raw["hot_ns"])[98]
    assert r["refreshed_median_ns"] == statistics.median(raw["refreshed_ns"])
    rss = re.search(r"(\d+)\s+maximum resident set size", Path(r["stderr"]).read_text())
    assert rss and int(rss[1]) == r["process_peak_rss_bytes"]
    observed[key] = r
assert observed.keys() == expected and report["terminal"] and report["all_paths_succeeded"]
for group in report["groups"]:
    for comparison, metrics in group["comparisons"].items():
        left, right = comparison.split("/")
        for metric, item in metrics.items():
            pairs = [observed[(group["api"], group["parameter_mode"], i, left)][metric] / observed[(group["api"], group["parameter_mode"], i, right)][metric] for i in range(1, 8)]
            median = statistics.median(pairs)
            assert item == {"median_left_over_right": median, "min": min(pairs), "max": max(pairs), "mad": statistics.median(abs(x - median) for x in pairs), "pairs": pairs}
result = {"terminal": True, "records": len(observed), "report_sha256": sha(OUT / "report.json"), "auditor_sha256": sha(Path(__file__)), "groups": report["groups"], "scope": report["scope"]}
(ROOT / "small-audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ["terminal", "records", "report_sha256", "auditor_sha256"]}, indent=2))
