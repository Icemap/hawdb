"""Freeze the unchanged mixed-growth probe on two exact independent source heads."""
from pathlib import Path
import hashlib,json,shutil,subprocess
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent.parent/"pr-986-result-accounting-source"
HEADS=json.loads((ROOT.parent/"selection.json").read_text())
def command(*args):return subprocess.check_output(args,cwd=SOURCE,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records={}
for name in ["baseline","1036"]:
 if command("git","status","--porcelain"):raise RuntimeError("source clone is dirty")
 revision=HEADS[name]
 subprocess.run(["git","checkout","--detach",revision],cwd=SOURCE,check=True)
 shutil.copy2(ROOT/"mixed_point_growth.rs",SOURCE/"benches/mixed_point_growth.rs")
 p=SOURCE/"benchmarks.bzl";text=p.read_text();needle="HAWDB_MANUAL_BENCHMARKS = [\n";assert text.count(needle)==1;p.write_text(text.replace(needle,needle+"    \"mixed_point_growth\",\n"))
 subprocess.run(["git","add","benchmarks.bzl","benches/mixed_point_growth.rs"],cwd=SOURCE,check=True)
 patch=ROOT/(name+"-overlay.patch");patch.write_bytes(subprocess.check_output(["git","diff","--cached","--binary",revision],cwd=SOURCE))
 tree=command("git","write-tree")
 print(name,revision,tree,"building",flush=True)
 with (ROOT/(name+"-build.log")).open("w") as log:subprocess.run(["bazel","build","-c","opt","//:hawdb_bench_mixed_point_growth"],cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert command("git","write-tree")==tree and command("git","rev-parse","HEAD")==revision
 subprocess.run(["git","diff","--exit-code"],cwd=SOURCE,check=True)
 original=(SOURCE/"bazel-bin/hawdb_bench_mixed_point_growth").resolve(strict=True);frozen=ROOT/(name+"-producer");before=sha(original);shutil.copy2(original,frozen);assert before==sha(original)==sha(frozen)
 records[name]={"head":revision,"base_tree":command("git","rev-parse","HEAD^{tree}"),"measured_tree":tree,"overlay_patch_sha256":sha(patch),"probe_sha256":sha(ROOT/"mixed_point_growth.rs"),"binary":str(frozen),"binary_sha256":before,"build":"bazel build -c opt //:hawdb_bench_mixed_point_growth; default configuration"}
 (ROOT/"producers.json").write_text(json.dumps(records,indent=2)+"\n")
 subprocess.run(["git","apply","-R","--index",str(patch)],cwd=SOURCE,check=True)
 assert not command("git","status","--porcelain")
 print(name,"frozen and source restored",flush=True)
subprocess.run(["git","checkout","extract/986-query-planning"],cwd=SOURCE,check=True)
assert not command("git","status","--porcelain")
print("ALL_FROZEN",flush=True)
