"""Alternate exact-source mixed-growth controls; preserve every outcome."""
from pathlib import Path
import hashlib
import itertools
import json
import statistics
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "harness/bindings/benchmarks"))
import run as harness

PRODUCERS = json.loads((ROOT / "producers.json").read_text())
DESTINATION = ROOT / "report.json"
DRIVER_SHA = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
requested = set(itertools.product([1000, 10000], ["raw", "admitted"], ["stable", "rotating"], range(8), ["baseline", "1036"]))
report = {"terminal": False, "driver_sha256": DRIVER_SHA, "producers": PRODUCERS, "records": [], "scope": "Default-opt exact-source macOS ARM64 mixed-growth control. Raw/admitted, stable/rebound parameters, 1k/10k memory stores, 100 hot and 100 post-diagnostic point calls per process. One discarded and seven alternating pairs. Original unchanged probe verifies every point value. No cross-language, allocator, file-backend, absolute SLO, retained/Arrow or original 986 full acceptance claim."}
if DESTINATION.exists():
    report = json.loads(DESTINATION.read_text())
    assert report["driver_sha256"] == DRIVER_SHA and report["producers"] == PRODUCERS
seen = {(r["requested_rows"], r["requested_api"], r["requested_parameter_mode"], r["iteration"], r["producer"]) for r in report["records"]}
assert len(seen) == len(report["records"])


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def guard():
    assert sha(Path(__file__)) == DRIVER_SHA
    for producer in PRODUCERS.values():
        assert sha(Path(producer["binary"])) == producer["binary_sha256"]
        assert sha(ROOT / "mixed_point_growth.rs") == producer["probe_sha256"]


def save():
    temporary = DESTINATION.with_suffix(".tmp")
    temporary.write_text(json.dumps(report, indent=2) + "\n")
    temporary.replace(DESTINATION)


guard()
save()
for rows in [1000, 10000]:
    for mode in ["stable", "rotating"]:
        for iteration in range(8):
            apis = ["raw", "admitted"] if iteration % 2 == 0 else ["admitted", "raw"]
            names = ["baseline", "1036"] if iteration % 2 == 0 else ["1036", "baseline"]
            for api in apis:
                for name in names:
                    key = (rows, api, mode, iteration, name)
                    if key in seen:
                        continue
                    guard()
                    prefix = ROOT / f"{rows}-{api}-{mode}-{iteration}-{name}"
                    record = harness.run_child([PRODUCERS[name]["binary"], str(rows), "-", api, mode], prefix)
                    record.update(producer=name, requested_rows=rows, requested_api=api, requested_parameter_mode=mode, iteration=iteration, discarded=iteration == 0)
                    record["qualified"] = bool(record["status"] == "ok" and record["process_exit"] == 0 and record.get("rows") == rows and record.get("api") == api and record.get("parameter_mode") == mode and record.get("backend") == "memory" and record.get("initial_rows") == 4 and record.get("independent_growth_statements") == rows - 4 and record.get("point_calls_per_phase") == 100 and len(record.get("hot_ns", [])) == 100 and len(record.get("refreshed_ns", [])) == 100 and record.get("durability") == "SyncOnEveryWrite")
                    if record["qualified"]:
                        assert all(type(t) is int and t >= 0 for t in record["hot_ns"] + record["refreshed_ns"])
                        record.update(first_hot_ns=record["hot_ns"][0], hot_median_ns=statistics.median(record["hot_ns"]), hot_p95_ns=sorted(record["hot_ns"])[94], hot_p99_ns=sorted(record["hot_ns"])[98], total_hot_ns=sum(record["hot_ns"]), refreshed_median_ns=statistics.median(record["refreshed_ns"]))
                    for stream in ["stdout", "stderr"]:
                        record[stream + "_sha256"] = sha(Path(record[stream]))
                    report["records"].append(record)
                    seen.add(key)
                    save()
                    guard()
                    print(rows, api, mode, iteration, name, record["status"], record["qualified"], record.get("first_hot_ns"), flush=True)
report["groups"] = []
for rows, api, mode in itertools.product([1000, 10000], ["raw", "admitted"], ["stable", "rotating"]):
    records = [r for r in report["records"] if (r["requested_rows"], r["requested_api"], r["requested_parameter_mode"]) == (rows, api, mode)]
    group = {"rows": rows, "api": api, "parameter_mode": mode, "complete": len(records) == 16, "qualified": len(records) == 16 and all(r["qualified"] for r in records)}
    if group["qualified"]:
        group["ratios"] = {}
        for metric in ["growth_ns", "first_hot_ns", "total_hot_ns", "hot_median_ns", "hot_p95_ns", "hot_p99_ns", "refreshed_median_ns", "process_peak_rss_bytes"]:
            pairs = []
            for iteration in range(1, 8):
                pair = {r["producer"]: r for r in records if r["iteration"] == iteration}
                pairs.append(pair["baseline"][metric] / pair["1036"][metric])
            median = statistics.median(pairs)
            group["ratios"][metric] = {"median_baseline_over_candidate": median, "min": min(pairs), "max": max(pairs), "mad": statistics.median(abs(t - median) for t in pairs), "pairs": pairs}
    report["groups"].append(group)
guard()
report["terminal"] = seen == requested
report["all_paths_succeeded"] = report["terminal"] and all(r["qualified"] for r in report["records"])
save()
print("TERMINAL", len(seen), report["all_paths_succeeded"], flush=True)
