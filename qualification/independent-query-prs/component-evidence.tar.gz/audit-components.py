"""Independently reconstruct protocol hashes, requested geometry and fixture checksums."""
from pathlib import Path
import collections, hashlib, json, sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/"harness/bindings/benchmarks"))
import run as matrix
p=ROOT/"components";r=json.loads((p/"report.json").read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert r["terminal"] is True
for name,h in r["raw_sha256"].items():assert sha(p/name)==h,name
for name,h in r["inputs"].items():assert sha(ROOT/name)==h,name
assert len(r["normalizer"])==234 and len(r["owned"])==138
assert r["protocols"]["before"]==r["protocols"]["second"] and len(r["protocols"]["before"])==13
for item in r["protocols"]["before"]:
 def digest(domain,fields,prefix):
  b=domain.encode();h=hashlib.sha256();h.update(len(b).to_bytes(8,"little"));h.update(b);h.update((1).to_bytes(2,"little"))
  for x in fields:
   b=x.encode();h.update(len(b).to_bytes(8,"little"));h.update(b)
  return prefix+"1:"+h.hexdigest()
 assert item["query_digest"]==digest("hawdb-query-digest",[item["language"].strip().lower(),item["normalized"]],"q")
 assert item["query_text_hash"]==digest("hawdb-query-text",[item["language"].strip().lower(),item["query"]],"t")
 assert item["cache_after_capacity"]==len(item["cache_key"].encode())<=item["cache_before_capacity"]
groups=collections.defaultdict(dict)
for item in r["normalizer"]:
 key=(item["iteration"],item["phase"],item["case"]);assert item["producer"] not in groups[key]
 groups[key][item["producer"]]=item
 assert item["allocated_bytes"]==item["deallocated_bytes"] and item["live_requested_bytes_before"]==item["live_requested_bytes_after"]
for key,g in groups.items():
 assert set(g)=={"before","second"},key
 for k in ["allocation_calls","allocated_bytes","reallocation_calls"]:assert g["second"][k]<=g["before"][k],(key,k)
assert len(groups)==117

def power(n):return 1<<(n-1).bit_length() if n else 0
def cells(n):return n//256*256+power(n%256)
def directory(n):return 24*power((n+255)//256) if n>256 else 0
undercharged=[]
for item in r["owned"]:
 x=item["result"];producer=item["producer"];kind=item["kind"]
 if producer=="1029" and kind=="scalar":
  n=int(item["arguments"][0]);expected=172+32*3*cells(n)+directory(n)+24*n
  assert x["rows"]==n and x["payload_bytes"]==40*n+12
  assert x["retained_requested_bytes"]==x["result_ledger_retained_bytes"]==expected
  assert expected<=x["result_ledger_peak_bytes"]<=16777216
  assert x["live_requested_bytes_before"]==x["live_requested_bytes_after_release"]
 elif kind in ["scalar","wide"]:
  n=x["accepted_rows"];requested=int(item["arguments"][0]);limit=2880 if producer=="1029" else (25420 if kind=="scalar" else 2405)
  assert n==min(requested,limit) and x["checksum"]==matrix.fixture(n,"wide" if kind=="wide" else "select")["expected_checksum"]
  assert x["before"]==x["after_release"] and x["ledger_retained_bytes"]<=x["ledger_peak_bytes"]<=16777216
  if requested>limit:assert x["first_refused_row"]==limit+1 and "result_materialization" in x["failure"]
  else:assert x["first_refused_row"] is None and x["failure"]==""
  if producer=="1029":
   expected=631+32*20*cells(n)+directory(n)+4590*n+2*sum(i%37>=10 for i in range(n))
   assert x["native_retained_requested_bytes"]==expected
   assert x["ledger_retained_bytes"]==expected+576*n
 elif kind=="map":
  a,n=map(int,item["arguments"]);assert x["inserted"]==a and x["remaining"]==n
  assert x["before"]==x["after_release"] and (x["value_size"],x["pair_size"],x["pointer_size"])==(32,56,8)
  if producer=="1029":assert x["ledger_retained_bytes"]==149+10*n+(1+max(0,n-1)//5)*728
  if x["native_retained_requested_bytes"]>x["ledger_retained_bytes"]:
   assert producer=="baseline";undercharged.append((a,n,x["native_retained_requested_bytes"],x["ledger_retained_bytes"]))
  else:assert x["native_retained_requested_bytes"]<=x["ledger_retained_bytes"]<=x["ledger_peak_bytes"]<=1048576
assert undercharged
summary={"terminal":True,"normalizer_records":234,"normalizer_groups_per_round":39,"protocol_records":13,"all_117_paired_component_groups_nonregressing":True,"owned_records":138,"owned_shapes_per_producer":23,"baseline_map_undercharges":undercharged,"candidate_scalar_100k_retained_requested_bytes":12021676,"candidate_scalar_100k_ledger_peak_bytes":12033984,"candidate_wide_first_refused_row":2881,"baseline_wide_first_refused_row":2406,"report_sha256":sha(p/"report.json"),"auditor_sha256":sha(Path(__file__)),"scope":r["scope"]}
(p/"audit.json").write_text(json.dumps(summary,indent=2)+"\n");print(json.dumps(summary,indent=2))
