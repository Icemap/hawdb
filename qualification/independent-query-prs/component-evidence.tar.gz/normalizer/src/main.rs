mod native_alloc;

use normalizer_prototype::{before, corpus, second};
use serde_json::json;
use std::hint::black_box;

const CALLS: usize = 1000;

fn execute(producer: &str, phase: &str, language: &str, query: &str) {
    match (producer, phase) {
        ("before", "identity") => drop(black_box(before::normalize_query(language, query))),
        ("second", "identity") => drop(black_box(second::normalize_query(language, query))),
        ("before", "cache_key") => drop(black_box(before::normalize_query_for_plan_cache(
            language, query,
        ))),
        ("second", "cache_key") => drop(black_box(second::normalize_query_for_plan_cache(
            language, query,
        ))),
        ("before", "query_identity") => {
            drop(black_box(before::QueryIdentity::new(language, query)))
        }
        ("second", "query_identity") => {
            drop(black_box(second::QueryIdentity::new(language, query)))
        }
        _ => unreachable!(),
    }
}

fn main() {
    let arguments = std::env::args().collect::<Vec<_>>();
    assert_eq!(arguments.len(), 3);
    let producer = arguments[1].as_str();
    let phase = arguments[2].as_str();
    assert!(matches!(producer, "before" | "second"));
    assert!(matches!(
        phase,
        "identity" | "cache_key" | "query_identity" | "protocol"
    ));
    for (case, language, query) in corpus::cases() {
        let old_identity = before::QueryIdentity::new(language, &query);
        let new_identity = second::QueryIdentity::new(language, &query);
        assert_eq!(
            old_identity.normalized_query(),
            new_identity.normalized_query()
        );
        assert_eq!(old_identity.query_digest(), new_identity.query_digest());
        assert_eq!(
            old_identity.query_text_hash(),
            new_identity.query_text_hash()
        );
        let old = before::normalize_query_for_plan_cache(language, &query);
        let new = second::normalize_query_for_plan_cache(language, &query);
        assert_eq!(old, new);
        assert_eq!(new.capacity(), new.len());
        assert!(new.capacity() <= old.capacity());
        if phase == "protocol" {
            println!(
                "{}",
                json!({"case":case,"language":language,"query":query,
                "normalized":old_identity.normalized_query(),"cache_key":old,
                "query_digest":old_identity.query_digest(),"query_text_hash":old_identity.query_text_hash(),
                "cache_before_capacity":old.capacity(),"cache_after_capacity":new.capacity()})
            );
            continue;
        }
        execute(producer, phase, language, &query);
        let start = native_alloc::snapshot();
        for _ in 0..CALLS {
            execute(producer, phase, language, &query);
        }
        let end = native_alloc::snapshot();
        let allocated = end.allocated_bytes - start.allocated_bytes;
        let deallocated = end.deallocated_bytes - start.deallocated_bytes;
        assert_eq!(allocated, deallocated);
        assert_eq!(start.live_requested_bytes, end.live_requested_bytes);
        println!(
            "{}",
            json!({"producer":producer,"phase":phase,"case":case,"language":language,
            "query_bytes":query.len(),"calls":CALLS,
            "allocation_calls":end.allocation_calls-start.allocation_calls,
            "allocated_bytes":allocated,"deallocated_bytes":deallocated,
            "reallocation_calls":end.reallocation_calls-start.reallocation_calls,
            "live_requested_bytes_before":start.live_requested_bytes,
            "live_requested_bytes_after":end.live_requested_bytes,
            "normalized_bytes":old_identity.normalized_query().len(),"cache_key_bytes":old.len(),
            "query_digest":old_identity.query_digest(),"query_text_hash":old_identity.query_text_hash(),
            "scope":"Instrumented copied production normalizer requests; no ordinary latency, foreign heap, physical-copy or whole-memory claim."})
        );
    }
}
