pub fn cases() -> Vec<(&'static str, &'static str, String)> {
    let property = format!("Field_{}", "x".repeat(16 * 1024));
    let parameter = format!("Parameter_{}", "p".repeat(16 * 1024));
    vec![
        ("point", "cypher", "MATCH (n:Boundary) WHERE n.id = $id RETURN n.id AS id, n.score AS score, n.title AS title".to_owned()),
        ("fill", "cypher", "CREATE (:Boundary {id: $id, score: $score, title: $title})".to_owned()),
        ("fill_bulk", "cypher", "UNWIND $rows AS row CREATE (:Boundary {id: row.id, score: row.score, title: row.title})".to_owned()),
        ("wide", "cypher", "MATCH (n:Boundary) RETURN n.id AS id, n.score AS score, n.title AS title, n.body AS body".to_owned()),
        ("literal_16k", "cypher", format!("RETURN '{}' AS value;;;", "x".repeat(16 * 1024))),
        ("lexical_identifier_1", "cypher", "z".to_owned()),
        ("small_statement", "cypher", "RETURN 1".to_owned()),
        (
            "label_1024",
            "cypher",
            format!("MATCH (n:Label_{}) WHERE n.score >= $min RETURN n.score", "a".repeat(1024)),
        ),
        (
            "property_16384",
            "cypher",
            format!("MATCH (n:Boundary) WHERE n.{property} >= $min RETURN n.{property} AS value"),
        ),
        (
            "parameter_16384",
            "cypher",
            format!("MATCH (n:Boundary) WHERE n.id = ${parameter} OR n.other = ${parameter} RETURN n.id"),
        ),
        (
            "quoted_identifier_utf8_16384",
            "sql",
            format!("SELECT \"{}\" FROM Boundary WHERE score >= $min", "\u{10400}".repeat(4096)),
        ),
        (
            "many_identifiers",
            "cypher",
            format!("RETURN {}", (0..128).map(|i| format!("Field_{i}_{}", "x".repeat(256))).collect::<Vec<_>>().join(",")),
        ),
        (
            "quoted_identifier_escape",
            "sql",
            format!("SELECT \"{}\" FROM Boundary", "ab\"\"CD".repeat(4096)),
        ),
    ]
}

#[cfg(test)]
mod tests {
    use crate::{before, second};

    #[test]
    fn long_identifier_protocols_and_owned_capacities_match() {
        for (_, _, query) in super::cases() {
            for language in ["cypher", "CyPhEr", " CYPHER ", "sql", " SQL ", "other"] {
                for (old, new) in [
                    (
                        before::normalize_query(language, &query),
                        second::normalize_query(language, &query),
                    ),
                    (
                        before::normalize_query_for_plan_cache(language, &query),
                        second::normalize_query_for_plan_cache(language, &query),
                    ),
                ] {
                    assert_eq!(old, new);
                    assert_eq!(new.capacity(), new.len());
                    assert!(new.capacity() <= old.capacity());
                }
                let old = before::QueryIdentity::new(language, &query);
                let new = second::QueryIdentity::new(language, &query);
                assert_eq!(old.normalized_query(), new.normalized_query());
                assert_eq!(old.query_digest(), new.query_digest());
                assert_eq!(old.query_text_hash(), new.query_text_hash());
            }
        }
    }
}
