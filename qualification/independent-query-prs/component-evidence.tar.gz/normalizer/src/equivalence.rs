use crate::{before, second};

fn compare(language: &str, query: &str) {
    assert_eq!(
        before::normalize_query(language, query),
        second::normalize_query(language, query)
    );
    assert_eq!(
        before::normalize_query_for_plan_cache(language, query),
        second::normalize_query_for_plan_cache(language, query)
    );
}

#[test]
fn exhaustive_short_inputs_preserve_normalized_bytes() {
    const ALPHABET: [char; 12] = [
        'a',
        'A',
        '$',
        '1',
        '-',
        '.',
        ';',
        '\'',
        '"',
        '\\',
        '\n',
        '\u{1f642}',
    ];
    let mut count = 0;
    for length in 0..=5 {
        for mut encoded in 0..ALPHABET.len().pow(length) {
            let query: String = (0..length)
                .map(|_| {
                    let character = ALPHABET[encoded % ALPHABET.len()];
                    encoded /= ALPHABET.len();
                    character
                })
                .collect();
            for language in ["cypher", "sql"] {
                compare(language, &query);
            }
            count += 1;
        }
    }
    assert_eq!(count, 271_453);
}
