# Source-bound component evidence

Issue Number: ref #1004, ref #1008

Extract this archive into a fresh directory and run `python3 -B verify-package.py`.
The auditor reconstructs protocol hashes, fixture checksums and native requested
capacity geometry from preserved inputs and all raw outcomes. It does not execute
benchmark binaries. The measured frozen binaries remain in the operator workspace;
their hashes and pinned source identities are recorded in the manifests. Rebuilding
elsewhere creates a new producer and must not relabel these receipts.

The normalizer source modules are exact copies of main 051ec037 and PR #1028
d67ec121. Native owned-result producers use main 051ec037 and PR #1029 079eb2da
with the original scalar, heterogeneous-wide and map-history fixtures. All requested
allocation counts were captured on pinned Rust 1.97.1, macOS ARM64. The scoped
64-bit std/ABI assumptions and conservative map bound are documented in #1029.

The initial baseline witness build omitted a checksum module; its build failure
is preserved but excluded from measured results. The corrected final build
precedes all raw measurements. No ordinary CPU/RSS/latency or original #986
performance gate is qualified by these component observations.
