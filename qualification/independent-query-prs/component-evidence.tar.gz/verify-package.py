"""Check archived bytes and exact module sources before auditing outcomes."""
from pathlib import Path
import hashlib
import json
import runpy
ROOT = Path(__file__).resolve().parent
for name, expected in json.loads((ROOT / "package-files.json").read_text()).items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
source = json.loads((ROOT / "normalizer/source.json").read_text())
report = json.loads((ROOT / "components/report.json").read_text())
assert source == report["normalizer_source"]
for name, expected in source["module_sha256"].items():
    path = ROOT / "normalizer/src" / (name + ".rs")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
runpy.run_path(str(ROOT / "audit-components.py"), run_name="__main__")
