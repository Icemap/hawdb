"""Collect raw component allocation receipts without ordinary latency timers."""
from pathlib import Path
import hashlib, json, shutil, subprocess
ROOT = Path(__file__).resolve().parent
out=ROOT/"components";out.mkdir(exist_ok=False);(out/"raw").mkdir();(out/"artifacts").mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
normalizer=ROOT/"normalizer"
binary=out/"artifacts/normalizer";shutil.copyfile(normalizer/"target/release/normalizer-prototype",binary);binary.chmod(0o755)
report={"normalizer_source":json.loads((normalizer/"source.json").read_text()),"normalizer_binary_sha256":sha(binary),"normalizer":[],"protocols":{},"owned":[],"terminal":False,"scope":"Fresh exact-source component requested-allocation evidence. No CPU/RSS/latency or whole-query qualification."}
for producer in ["before","second"]:
 p=out/"raw"/("protocol-"+producer)
 r=subprocess.run([str(binary),producer,"protocol"],capture_output=True)
 p.with_suffix(".stdout").write_bytes(r.stdout);p.with_suffix(".stderr").write_bytes(r.stderr)
 assert r.returncode==0,r.stderr.decode()
 report["protocols"][producer]=[json.loads(x) for x in r.stdout.splitlines()]
for iteration in range(3):
 for phase in ["identity","cache_key","query_identity"]:
  for producer in (["before","second"] if iteration%2==0 else ["second","before"]):
   p=out/"raw"/f"normalizer-{iteration}-{phase}-{producer}"
   r=subprocess.run([str(binary),producer,phase],capture_output=True)
   p.with_suffix(".stdout").write_bytes(r.stdout);p.with_suffix(".stderr").write_bytes(r.stderr)
   assert r.returncode==0,r.stderr.decode()
   for line in r.stdout.splitlines():report["normalizer"].append({**json.loads(line),"iteration":iteration})
for name,directory in [("baseline","owned-baseline"),("1029","owned")]:
 manifest=json.loads((ROOT/directory/"manifest.json").read_text())
 for kind,args in [("scalar",[[str(n)] for n in [1,1000,25420,25421,100000]]),("wide",[[str(n)] for n in [1,256,257,1000,5408,5409,10000]]),("map",[[str(a),str(b)] for a,b in [(0,0),(1,0),(1,1),(2,2),(11,11),(12,12),(100,100),(1000,1000),(1000,10),(1000,1),(1000,0)]])]:
  artifact=manifest["artifacts"]["owned_"+kind+"_capacity"]
  assert sha(Path(artifact["path"]))==artifact["sha256"]
  for iteration in range(3):
   for a in args:
    p=out/"raw"/(f"owned-{name}-{kind}-{iteration}-"+"-".join(a))
    r=subprocess.run([artifact["path"],*a],capture_output=True)
    p.with_suffix(".stdout").write_bytes(r.stdout);p.with_suffix(".stderr").write_bytes(r.stderr)
    assert r.returncode==0,(name,kind,a,r.stderr.decode())
    report["owned"].append({"producer":name,"kind":kind,"iteration":iteration,"arguments":a,"result":json.loads(r.stdout)})
report["terminal"]=True
report["inputs"]={str(p.relative_to(ROOT)):sha(p) for p in [Path(__file__),normalizer/"Cargo.toml",normalizer/"Cargo.lock",normalizer/"src/main.rs",normalizer/"src/native_alloc.rs",normalizer/"src/corpus.rs",ROOT/"owned/manifest.json",ROOT/"owned-baseline/manifest.json"]}
report["raw_sha256"]={str(p.relative_to(out)):sha(p) for p in (out/"raw").iterdir()}
(out/"report.json").write_text(json.dumps(report,indent=2)+"\n")
print("COMPONENTS_TERMINAL",len(report["normalizer"]),len(report["owned"]),flush=True)
