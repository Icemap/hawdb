"""Build requested-allocation witnesses against exact owned-accounting PR source."""
from pathlib import Path
import hashlib, json, shutil, subprocess
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent.parent / "pr-986-result-accounting-source"
revision = "079eb2dad26e0a20a1182470991194daf8a2d0a2"
def command(*a): return subprocess.check_output(a,cwd=SOURCE,text=True).strip()
assert not command("git","status","--porcelain")
subprocess.run(["git","checkout","--detach",revision],cwd=SOURCE,check=True)
base = command("git","rev-parse","HEAD^{tree}")
names = ["owned_scalar_capacity","owned_wide_capacity","owned_map_capacity"]
p = SOURCE / "benchmarks.bzl"
s = p.read_text(); marker = "HAWDB_MANUAL_BENCHMARKS = [\n"
assert s.count(marker)==1
p.write_text(s.replace(marker,marker+"".join('    "'+name+'",\n' for name in names)))
added=[]
for f in (ROOT/"harness").rglob("*"):
 if f.is_file():
  rel=f.relative_to(ROOT/"harness");d=SOURCE/rel
  assert not d.exists();d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,d);added.append(str(rel))
subprocess.run(["git","add","--","benchmarks.bzl",*added],cwd=SOURCE,check=True)
tree=command("git","write-tree")
patch=ROOT/"overlay.patch";patch.write_bytes(subprocess.check_output(["git","diff","--cached","--binary",revision],cwd=SOURCE))
with (ROOT/"build.log").open("w") as log:
 subprocess.run(["bazel","build","-c","opt",*["//:hawdb_bench_"+name for name in names]],cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,check=True)
assert command("git","write-tree")==tree
subprocess.run(["git","diff","--exit-code"],cwd=SOURCE,check=True)
artifacts=ROOT/"artifacts";artifacts.mkdir()
records={}
for name in names:
 src=SOURCE/"bazel-bin"/("hawdb_bench_"+name);d=artifacts/name;shutil.copyfile(src,d);d.chmod(0o755)
 records[name]={"path":str(d),"sha256":hashlib.sha256(d.read_bytes()).hexdigest()}
(ROOT/"manifest.json").write_text(json.dumps({"head":revision,"base_tree":base,"measured_tree":tree,"overlay_sha256":hashlib.sha256(patch.read_bytes()).hexdigest(),"artifacts":records,"build":"bazel build -c opt; defaults unchanged; exact prior fixture/value/counter sources"},indent=2)+"\n")
subprocess.run(["git","apply","-R","--index",str(patch)],cwd=SOURCE,check=True)
subprocess.run(["git","checkout","extract/986-query-planning"],cwd=SOURCE,check=True)
assert not command("git","status","--porcelain")
print("OWNED_WITNESSES_FROZEN",tree,flush=True)
