//! Native allocation witness for map shape and deletion history.
#[path = "owned_map_capacity/native_alloc.rs"]
mod native_alloc;
use hawdb_core::{Value, ValueRef};
use hawdb_executor::{
    binding::Binding,
    result_delivery::{OutputLimits, QueryOutputAccumulator},
    QueryMemoryLedger, Row,
};
use serde_json::json;
use std::num::NonZeroUsize;
fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    let inserted = args[1].parse::<usize>().unwrap();
    let remaining = args[2].parse::<usize>().unwrap();
    assert!(remaining <= inserted);
    let baseline = native_alloc::snapshot();
    let mut map = Row::new();
    for id in 0..inserted {
        map.insert(
            format!("key-{id:06}").into_boxed_str().into_string(),
            Value::Int(id as i64),
        );
    }
    for id in 0..inserted - remaining {
        map.remove(&format!("key-{id:06}"));
    }
    let ledger = QueryMemoryLedger::new(NonZeroUsize::new(8 * 1024 * 1024).unwrap());
    let mut builder = QueryOutputAccumulator::new_owned(
        OutputLimits::default(),
        NonZeroUsize::new(1024 * 1024).unwrap(),
        &ledger,
    )
    .unwrap();
    builder
        .emit(Binding::values(Row::from([(
            "value".into(),
            Value::Map(map),
        )])))
        .unwrap();
    let snapshot = ledger.snapshot();
    let charged = snapshot.used_bytes;
    let peak = snapshot.peak_bytes;
    drop(snapshot);
    let output = builder.take_owned_rows().unwrap();
    drop(builder);
    drop(ledger);
    let collected = native_alloc::snapshot();
    let Some(ValueRef::Map(map)) = output.get(0, "value") else {
        panic!("expected map");
    };
    assert_eq!(map.len(), remaining);
    for (ordinal, (key, value)) in map.iter().enumerate() {
        let id = inserted - remaining + ordinal;
        assert_eq!(key, &format!("key-{id:06}"));
        assert_eq!(value, &Value::Int(id as i64));
    }
    drop(output);
    let released = native_alloc::snapshot();
    assert_eq!(released.live_requested_bytes, baseline.live_requested_bytes);
    println!(
        "{}",
        json!({"inserted":inserted,"remaining":remaining,"ledger_retained_bytes":charged,"ledger_peak_bytes":peak,"native_retained_requested_bytes":collected.live_requested_bytes-baseline.live_requested_bytes,"before":baseline.live_requested_bytes,"after_release":released.live_requested_bytes,"value_size":std::mem::size_of::<Value>(),"pair_size":std::mem::size_of::<(String,Value)>(),"pointer_size":std::mem::size_of::<usize>(),"scope":"Isolated map-shape native requested bytes; not engine, RSS, foreign heap or latency acceptance."})
    );
}
