//! Isolated heterogeneous result-capacity witness; no engine timing claim.
#[path = "owned_wide_capacity/checksum.rs"]
mod checksum;
#[path = "owned_wide_capacity/native_alloc.rs"]
mod native_alloc;
use hawdb_core::Value;
use hawdb_executor::{
    binding::{map_memory_bytes, Binding},
    result_delivery::{OutputLimits, QueryOutputAccumulator},
    QueryMemoryLedger,
};
use serde_json::json;
use std::{collections::BTreeMap, num::NonZeroUsize};
fn text(value: String) -> Value {
    Value::String(value.into_boxed_str().into_string())
}
fn row(index: usize, state: u32) -> BTreeMap<String, Value> {
    let mut row = BTreeMap::from([
        ("id".into(), Value::Int(index as i64)),
        ("score".into(), Value::Float(f64::from(state >> 8) + 0.5)),
        (
            "title".into(),
            text(format!("mem-{index:08x}-\u{77e5}\u{8bc6}\0\u{1f642}")),
        ),
    ]);
    for column in 3..20 {
        let value = match column % 7 {
            0 => Value::Int(-i64::from(state % 100000)),
            1 => Value::Float(f64::from(state % 10000) + 0.25),
            2 => text(format!("thread-{}-\u{754c}", index % 37)),
            3 => Value::List(vec![
                Value::Int(index as i64),
                Value::Null,
                text("\u{5185}\u{5bb9}".into()),
                Value::Bool(true),
            ]),
            4 => Value::Map(BTreeMap::from([
                ("id".into(), Value::Int(index as i64)),
                (
                    "nested".into(),
                    Value::List(vec![
                        text("\0".into()),
                        Value::Bool(false),
                        Value::Map(BTreeMap::from([(
                            "\u{6807}\u{9898}".into(),
                            text("value".into()),
                        )])),
                    ]),
                ),
            ])),
            5 => Value::Bool(index.is_multiple_of(2)),
            _ => Value::Null,
        };
        row.insert(format!("c{column:02}"), value);
    }
    row
}
fn main() {
    let count = std::env::args().nth(1).unwrap().parse::<usize>().unwrap();
    let budget = 16_777_216;
    let baseline = native_alloc::snapshot();
    let ledger = QueryMemoryLedger::new(NonZeroUsize::new(256 * 1024 * 1024).unwrap());
    let mut builder = QueryOutputAccumulator::new_owned(
        OutputLimits::default(),
        NonZeroUsize::new(budget).unwrap(),
        &ledger,
    )
    .unwrap();
    let mut state = 0x5eedu32;
    let mut accepted = 0;
    let mut first_refused = None;
    let mut cumulative_map = 0;
    let mut failure = [0u8; 256];
    let mut failure_len = 0;
    for index in 0..count {
        state = state.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
        let row = row(index, state);
        cumulative_map += map_memory_bytes(&row);
        if let Err(error) = builder.emit(Binding::values(row)) {
            let message = error.to_string();
            assert!(message.contains("budget"), "unexpected refusal: {message}");
            assert!(message.len() <= failure.len());
            failure_len = message.len();
            failure[..failure_len].copy_from_slice(message.as_bytes());
            first_refused = Some(index + 1);
            break;
        }
        accepted += 1;
    }
    let snapshot = ledger.snapshot();
    let used = snapshot.used_bytes;
    let peak = snapshot.peak_bytes;
    drop(snapshot);
    let output = builder.take_owned_rows().unwrap();
    drop(builder);
    drop(ledger);
    let collected = native_alloc::snapshot();
    assert_eq!(output.len(), accepted);
    let mut hash = checksum::Checksum::new(output.schema().columns());
    let mut state = 0x5eedu32;
    for index in 0..accepted {
        state = state.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
        let expected = row(index, state);
        assert_eq!(output.schema().len(), expected.len());
        for (column, (name, value)) in expected.iter().enumerate() {
            assert_eq!(output.schema().columns()[column], *name);
            assert_eq!(output.value(index, column), Some(value.as_ref()));
        }
        hash.row(&expected.into_values().collect::<Vec<_>>());
    }
    let payload = output.payload_bytes();
    drop(output);
    let released = native_alloc::snapshot();
    assert_eq!(released.live_requested_bytes, baseline.live_requested_bytes);
    println!(
        "{}",
        json!({"checksum":hash.hex(),"requested_rows":count,"accepted_rows":accepted,"first_refused_row":first_refused,"failure":std::str::from_utf8(&failure[..failure_len]).unwrap(),"budget_bytes":budget,"ledger_retained_bytes":used,"ledger_peak_bytes":peak,"native_retained_requested_bytes":collected.live_requested_bytes-baseline.live_requested_bytes,"cumulative_map_estimate_bytes":cumulative_map,"payload_bytes":payload,"before":baseline.live_requested_bytes,"after_release":released.live_requested_bytes,"scope":"Exact wide fixture values with tight input payload capacities. Isolated owned collector only; nested map charges remain estimates. No engine, foreign-heap, RSS, latency or zero-copy qualification."})
    );
}
