//! Isolated collector witness, not an engine or zero-copy benchmark.

#[path = "owned_scalar_capacity/native_alloc.rs"]
mod native_alloc;

use hawdb_core::{Value, ValueRef};
use hawdb_executor::{
    binding::{map_memory_bytes, Binding},
    result_delivery::{OutputLimits, QueryOutputAccumulator},
    QueryMemoryLedger,
};
use serde_json::json;
use std::collections::BTreeMap;
use std::num::NonZeroUsize;

fn main() {
    let arguments = std::env::args().collect::<Vec<_>>();
    let count = arguments[1].parse::<usize>().expect("row count");
    let budget = 16_777_216usize;
    let baseline = native_alloc::snapshot();
    let ledger = QueryMemoryLedger::new(NonZeroUsize::new(256 * 1024 * 1024).unwrap());
    let mut builder = QueryOutputAccumulator::new_owned(
        OutputLimits::default(),
        NonZeroUsize::new(budget).unwrap(),
        &ledger,
    )
    .unwrap();
    let mut map_estimate = 0usize;
    let mut first_over_budget = None;
    let mut state = 0x5eedu32;
    for index in 0..count {
        state = state.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
        let title = format!("mem-{index:08x}-\u{77e5}\u{8bc6}\0\u{1f642}")
            .into_boxed_str()
            .into_string();
        let row = BTreeMap::from([
            ("id".to_owned(), Value::Int(index as i64)),
            (
                "score".to_owned(),
                Value::Float(f64::from(state >> 8) + 0.5),
            ),
            ("title".to_owned(), Value::String(title)),
        ]);
        map_estimate = map_estimate.checked_add(map_memory_bytes(&row)).unwrap();
        if map_estimate > budget && first_over_budget.is_none() {
            first_over_budget = Some(index + 1);
        }
        builder
            .emit(Binding::values(row))
            .expect("canonical row admission");
    }
    let ledger_snapshot = ledger.snapshot();
    let ledger_retained_bytes = ledger_snapshot.used_bytes;
    let ledger_peak_bytes = ledger_snapshot.peak_bytes;
    drop(ledger_snapshot);
    let output = builder.take_owned_rows().unwrap();
    drop(builder);
    drop(ledger);
    let collected = native_alloc::snapshot();
    assert_eq!(output.len(), count);
    assert_eq!(output.schema().columns(), &["id", "score", "title"]);
    let mut state = 0x5eedu32;
    for index in 0..count {
        state = state.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
        assert_eq!(output.value(index, 0), Some(ValueRef::Int(index as i64)));
        assert_eq!(
            output.value(index, 1),
            Some(ValueRef::Float(f64::from(state >> 8) + 0.5))
        );
        let Some(ValueRef::String(title)) = output.value(index, 2) else {
            panic!("missing title");
        };
        assert_eq!(title.len(), 24);
        assert!(title.starts_with("mem-"));
        assert_eq!(usize::from_str_radix(&title[4..12], 16), Ok(index));
        assert_eq!(&title[12..], "-\u{77e5}\u{8bc6}\0\u{1f642}");
    }
    let payload_bytes = output.payload_bytes();
    drop(output);
    let released = native_alloc::snapshot();
    assert_eq!(released.live_requested_bytes, baseline.live_requested_bytes);
    println!(
        "{}",
        json!({
            "rows": count,
            "result_ledger_retained_bytes": ledger_retained_bytes,
            "result_ledger_peak_bytes": ledger_peak_bytes,
            "budget_bytes": budget,
            "cumulative_map_estimate_bytes": map_estimate,
            "first_map_estimate_over_budget_row": first_over_budget,
            "retained_requested_bytes": collected.live_requested_bytes - baseline.live_requested_bytes,
            "live_requested_bytes_before": baseline.live_requested_bytes,
            "live_requested_bytes_after_release": released.live_requested_bytes,
            "allocated_bytes": collected.allocated_bytes - baseline.allocated_bytes,
            "deallocated_bytes": collected.deallocated_bytes - baseline.deallocated_bytes,
            "process_peak_requested_bytes": collected.process_peak_requested_bytes,
            "payload_bytes": payload_bytes,
            "value_size": std::mem::size_of::<Value>(),
            "map_size": std::mem::size_of::<BTreeMap<String, Value>>(),
            "entry_size": std::mem::size_of::<(String, Value)>(),
            "scope": "Isolated compact owned accumulator; original canonical fixture. No engine latency, source retention, foreign heap, physical-copy or whole-memory claim."
        })
    );
}
